<?php return array (
  'app' => 
  array (
    'name' => 'Laravel',
    'env' => 'local',
    'debug' => true,
    'url' => 'http://localhost',
    'asset_url' => NULL,
    'timezone' => 'UTC',
    'locale' => 'en',
    'fallback_locale' => 'en',
    'faker_locale' => 'en_US',
    'key' => 'base64:He3tuph067M/VXvQOF9bW6U2jHj6uZIiXqIAbGs+I5Q=',
    'cipher' => 'AES-256-CBC',
    'maintenance' => 
    array (
      'driver' => 'file',
    ),
    'providers' => 
    array (
      0 => 'Illuminate\\Auth\\AuthServiceProvider',
      1 => 'Illuminate\\Broadcasting\\BroadcastServiceProvider',
      2 => 'Illuminate\\Bus\\BusServiceProvider',
      3 => 'Illuminate\\Cache\\CacheServiceProvider',
      4 => 'Illuminate\\Foundation\\Providers\\ConsoleSupportServiceProvider',
      5 => 'Illuminate\\Cookie\\CookieServiceProvider',
      6 => 'Illuminate\\Database\\DatabaseServiceProvider',
      7 => 'Illuminate\\Encryption\\EncryptionServiceProvider',
      8 => 'Illuminate\\Filesystem\\FilesystemServiceProvider',
      9 => 'Illuminate\\Foundation\\Providers\\FoundationServiceProvider',
      10 => 'Illuminate\\Hashing\\HashServiceProvider',
      11 => 'Illuminate\\Mail\\MailServiceProvider',
      12 => 'Illuminate\\Notifications\\NotificationServiceProvider',
      13 => 'Illuminate\\Pagination\\PaginationServiceProvider',
      14 => 'Illuminate\\Pipeline\\PipelineServiceProvider',
      15 => 'Illuminate\\Queue\\QueueServiceProvider',
      16 => 'Illuminate\\Redis\\RedisServiceProvider',
      17 => 'Illuminate\\Auth\\Passwords\\PasswordResetServiceProvider',
      18 => 'Illuminate\\Session\\SessionServiceProvider',
      19 => 'Illuminate\\Translation\\TranslationServiceProvider',
      20 => 'Illuminate\\Validation\\ValidationServiceProvider',
      21 => 'Illuminate\\View\\ViewServiceProvider',
      22 => 'App\\Providers\\AppServiceProvider',
      23 => 'App\\Providers\\AuthServiceProvider',
      24 => 'App\\Providers\\EventServiceProvider',
      25 => 'App\\Providers\\RouteServiceProvider',
      26 => 'Mckenziearts\\Notify\\LaravelNotifyServiceProvider',
      27 => 'RealRashid\\SweetAlert\\SweetAlertServiceProvider',
    ),
    'aliases' => 
    array (
      'App' => 'Illuminate\\Support\\Facades\\App',
      'Arr' => 'Illuminate\\Support\\Arr',
      'Artisan' => 'Illuminate\\Support\\Facades\\Artisan',
      'Auth' => 'Illuminate\\Support\\Facades\\Auth',
      'Blade' => 'Illuminate\\Support\\Facades\\Blade',
      'Broadcast' => 'Illuminate\\Support\\Facades\\Broadcast',
      'Bus' => 'Illuminate\\Support\\Facades\\Bus',
      'Cache' => 'Illuminate\\Support\\Facades\\Cache',
      'Config' => 'Illuminate\\Support\\Facades\\Config',
      'Cookie' => 'Illuminate\\Support\\Facades\\Cookie',
      'Crypt' => 'Illuminate\\Support\\Facades\\Crypt',
      'Date' => 'Illuminate\\Support\\Facades\\Date',
      'DB' => 'Illuminate\\Support\\Facades\\DB',
      'Eloquent' => 'Illuminate\\Database\\Eloquent\\Model',
      'Event' => 'Illuminate\\Support\\Facades\\Event',
      'File' => 'Illuminate\\Support\\Facades\\File',
      'Gate' => 'Illuminate\\Support\\Facades\\Gate',
      'Hash' => 'Illuminate\\Support\\Facades\\Hash',
      'Http' => 'Illuminate\\Support\\Facades\\Http',
      'Js' => 'Illuminate\\Support\\Js',
      'Lang' => 'Illuminate\\Support\\Facades\\Lang',
      'Log' => 'Illuminate\\Support\\Facades\\Log',
      'Mail' => 'Illuminate\\Support\\Facades\\Mail',
      'Notification' => 'Illuminate\\Support\\Facades\\Notification',
      'Password' => 'Illuminate\\Support\\Facades\\Password',
      'Process' => 'Illuminate\\Support\\Facades\\Process',
      'Queue' => 'Illuminate\\Support\\Facades\\Queue',
      'RateLimiter' => 'Illuminate\\Support\\Facades\\RateLimiter',
      'Redirect' => 'Illuminate\\Support\\Facades\\Redirect',
      'Request' => 'Illuminate\\Support\\Facades\\Request',
      'Response' => 'Illuminate\\Support\\Facades\\Response',
      'Route' => 'Illuminate\\Support\\Facades\\Route',
      'Schema' => 'Illuminate\\Support\\Facades\\Schema',
      'Session' => 'Illuminate\\Support\\Facades\\Session',
      'Storage' => 'Illuminate\\Support\\Facades\\Storage',
      'Str' => 'Illuminate\\Support\\Str',
      'URL' => 'Illuminate\\Support\\Facades\\URL',
      'Validator' => 'Illuminate\\Support\\Facades\\Validator',
      'View' => 'Illuminate\\Support\\Facades\\View',
      'Vite' => 'Illuminate\\Support\\Facades\\Vite',
      'Alert' => 'RealRashid\\SweetAlert\\Facades\\Alert',
      'OEmbed' => 'Cohensive\\OEmbed\\Facades\\OEmbed',
    ),
  ),
  'auth' => 
  array (
    'defaults' => 
    array (
      'guard' => 'web',
      'passwords' => 'users',
    ),
    'guards' => 
    array (
      'web' => 
      array (
        'driver' => 'session',
        'provider' => 'users',
      ),
      'admin' => 
      array (
        'driver' => 'session',
        'provider' => 'admins',
      ),
      'sanctum' => 
      array (
        'driver' => 'sanctum',
        'provider' => NULL,
      ),
    ),
    'providers' => 
    array (
      'users' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\User',
      ),
      'admins' => 
      array (
        'driver' => 'eloquent',
        'model' => 'App\\Models\\Admin',
      ),
    ),
    'passwords' => 
    array (
      'users' => 
      array (
        'provider' => 'users',
        'table' => 'password_reset_tokens',
        'expire' => 60,
        'throttle' => 60,
      ),
    ),
    'password_timeout' => 10800,
  ),
  'broadcasting' => 
  array (
    'default' => 'log',
    'connections' => 
    array (
      'pusher' => 
      array (
        'driver' => 'pusher',
        'key' => '',
        'secret' => '',
        'app_id' => '',
        'options' => 
        array (
          'cluster' => 'mt1',
          'host' => 'api-mt1.pusher.com',
          'port' => '443',
          'scheme' => 'https',
          'encrypted' => true,
          'useTLS' => true,
        ),
        'client_options' => 
        array (
        ),
      ),
      'ably' => 
      array (
        'driver' => 'ably',
        'key' => NULL,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
      ),
      'log' => 
      array (
        'driver' => 'log',
      ),
      'null' => 
      array (
        'driver' => 'null',
      ),
    ),
  ),
  'cache' => 
  array (
    'default' => 'file',
    'stores' => 
    array (
      'apc' => 
      array (
        'driver' => 'apc',
      ),
      'array' => 
      array (
        'driver' => 'array',
        'serialize' => false,
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'cache',
        'connection' => NULL,
        'lock_connection' => NULL,
      ),
      'file' => 
      array (
        'driver' => 'file',
        'path' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\framework/cache/data',
        'lock_path' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\framework/cache/data',
      ),
      'memcached' => 
      array (
        'driver' => 'memcached',
        'persistent_id' => NULL,
        'sasl' => 
        array (
          0 => NULL,
          1 => NULL,
        ),
        'options' => 
        array (
        ),
        'servers' => 
        array (
          0 => 
          array (
            'host' => '127.0.0.1',
            'port' => 11211,
            'weight' => 100,
          ),
        ),
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'cache',
        'lock_connection' => 'default',
      ),
      'dynamodb' => 
      array (
        'driver' => 'dynamodb',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'table' => 'cache',
        'endpoint' => NULL,
      ),
      'octane' => 
      array (
        'driver' => 'octane',
      ),
    ),
    'prefix' => 'laravel_cache_',
  ),
  'chapa' => 
  array (
    'secretKey' => 'CHASECK_TEST-sb5vgMV1y5s7ysB9zCPWufzxQ2GMsDef',
  ),
  'cors' => 
  array (
    'paths' => 
    array (
      0 => 'api/*',
      1 => 'sanctum/csrf-cookie',
    ),
    'allowed_methods' => 
    array (
      0 => '*',
    ),
    'allowed_origins' => 
    array (
      0 => '*',
    ),
    'allowed_origins_patterns' => 
    array (
    ),
    'allowed_headers' => 
    array (
      0 => '*',
    ),
    'exposed_headers' => 
    array (
    ),
    'max_age' => 0,
    'supports_credentials' => false,
  ),
  'database' => 
  array (
    'default' => 'mysql',
    'connections' => 
    array (
      'sqlite' => 
      array (
        'driver' => 'sqlite',
        'url' => NULL,
        'database' => 'course',
        'prefix' => '',
        'foreign_key_constraints' => true,
      ),
      'mysql' => 
      array (
        'driver' => 'mysql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'course',
        'username' => 'root',
        'password' => '',
        'unix_socket' => '',
        'charset' => 'utf8mb4',
        'collation' => 'utf8mb4_unicode_ci',
        'prefix' => '',
        'prefix_indexes' => true,
        'strict' => true,
        'engine' => NULL,
        'options' => 
        array (
        ),
      ),
      'pgsql' => 
      array (
        'driver' => 'pgsql',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'course',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
        'search_path' => 'public',
        'sslmode' => 'prefer',
      ),
      'sqlsrv' => 
      array (
        'driver' => 'sqlsrv',
        'url' => NULL,
        'host' => '127.0.0.1',
        'port' => '3306',
        'database' => 'course',
        'username' => 'root',
        'password' => '',
        'charset' => 'utf8',
        'prefix' => '',
        'prefix_indexes' => true,
      ),
    ),
    'migrations' => 'migrations',
    'redis' => 
    array (
      'client' => 'phpredis',
      'options' => 
      array (
        'cluster' => 'redis',
        'prefix' => 'laravel_database_',
      ),
      'default' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '0',
      ),
      'cache' => 
      array (
        'url' => NULL,
        'host' => '127.0.0.1',
        'username' => NULL,
        'password' => NULL,
        'port' => '6379',
        'database' => '1',
      ),
    ),
  ),
  'filesystems' => 
  array (
    'default' => 'local',
    'disks' => 
    array (
      'local' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\app',
        'throw' => false,
      ),
      'public' => 
      array (
        'driver' => 'local',
        'root' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\app/public',
        'url' => 'http://localhost/storage',
        'visibility' => 'public',
        'throw' => false,
      ),
      's3' => 
      array (
        'driver' => 's3',
        'key' => '',
        'secret' => '',
        'region' => 'us-east-1',
        'bucket' => '',
        'url' => NULL,
        'endpoint' => NULL,
        'use_path_style_endpoint' => false,
        'throw' => false,
      ),
    ),
    'links' => 
    array (
      'C:\\Users\\yared\\Videos\\CourseEnroll\\public\\storage' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\app/public',
    ),
  ),
  'hashing' => 
  array (
    'driver' => 'bcrypt',
    'bcrypt' => 
    array (
      'rounds' => 10,
    ),
    'argon' => 
    array (
      'memory' => 65536,
      'threads' => 1,
      'time' => 4,
    ),
  ),
  'logging' => 
  array (
    'default' => 'stack',
    'deprecations' => 
    array (
      'channel' => NULL,
      'trace' => false,
    ),
    'channels' => 
    array (
      'stack' => 
      array (
        'driver' => 'stack',
        'channels' => 
        array (
          0 => 'single',
        ),
        'ignore_exceptions' => false,
      ),
      'single' => 
      array (
        'driver' => 'single',
        'path' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\logs/laravel.log',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'daily' => 
      array (
        'driver' => 'daily',
        'path' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\logs/laravel.log',
        'level' => 'debug',
        'days' => 14,
        'replace_placeholders' => true,
      ),
      'slack' => 
      array (
        'driver' => 'slack',
        'url' => NULL,
        'username' => 'Laravel Log',
        'emoji' => ':boom:',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'papertrail' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\SyslogUdpHandler',
        'handler_with' => 
        array (
          'host' => NULL,
          'port' => NULL,
          'connectionString' => 'tls://:',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'stderr' => 
      array (
        'driver' => 'monolog',
        'level' => 'debug',
        'handler' => 'Monolog\\Handler\\StreamHandler',
        'formatter' => NULL,
        'with' => 
        array (
          'stream' => 'php://stderr',
        ),
        'processors' => 
        array (
          0 => 'Monolog\\Processor\\PsrLogMessageProcessor',
        ),
      ),
      'syslog' => 
      array (
        'driver' => 'syslog',
        'level' => 'debug',
        'facility' => 8,
        'replace_placeholders' => true,
      ),
      'errorlog' => 
      array (
        'driver' => 'errorlog',
        'level' => 'debug',
        'replace_placeholders' => true,
      ),
      'null' => 
      array (
        'driver' => 'monolog',
        'handler' => 'Monolog\\Handler\\NullHandler',
      ),
      'emergency' => 
      array (
        'path' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\logs/laravel.log',
      ),
    ),
  ),
  'mail' => 
  array (
    'default' => 'smtp',
    'mailers' => 
    array (
      'smtp' => 
      array (
        'transport' => 'smtp',
        'url' => NULL,
        'host' => 'sandbox.smtp.mailtrap.io',
        'port' => '2525',
        'encryption' => 'tls',
        'username' => '97d3bf8990ef06',
        'password' => '0c44f6944abfee',
        'timeout' => NULL,
        'local_domain' => NULL,
      ),
      'ses' => 
      array (
        'transport' => 'ses',
      ),
      'mailgun' => 
      array (
        'transport' => 'mailgun',
      ),
      'postmark' => 
      array (
        'transport' => 'postmark',
      ),
      'sendmail' => 
      array (
        'transport' => 'sendmail',
        'path' => '/usr/sbin/sendmail -bs -i',
      ),
      'log' => 
      array (
        'transport' => 'log',
        'channel' => NULL,
      ),
      'array' => 
      array (
        'transport' => 'array',
      ),
      'failover' => 
      array (
        'transport' => 'failover',
        'mailers' => 
        array (
          0 => 'smtp',
          1 => 'log',
        ),
      ),
    ),
    'from' => 
    array (
      'address' => 'yared.ayele.me@gmail.com',
      'name' => 'Laravel',
    ),
    'markdown' => 
    array (
      'theme' => 'default',
      'paths' => 
      array (
        0 => 'C:\\Users\\yared\\Videos\\CourseEnroll\\resources\\views/vendor/mail',
      ),
    ),
  ),
  'notify' => 
  array (
    'theme' => 'light',
    'timeout' => 5000,
    'preset-messages' => 
    array (
      'user-updated' => 
      array (
        'message' => 'The user has been updated successfully.',
        'type' => 'success',
        'model' => 'connect',
        'title' => 'User Updated',
      ),
    ),
  ),
  'queue' => 
  array (
    'default' => 'sync',
    'connections' => 
    array (
      'sync' => 
      array (
        'driver' => 'sync',
      ),
      'database' => 
      array (
        'driver' => 'database',
        'table' => 'jobs',
        'queue' => 'default',
        'retry_after' => 90,
        'after_commit' => false,
      ),
      'beanstalkd' => 
      array (
        'driver' => 'beanstalkd',
        'host' => 'localhost',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => 0,
        'after_commit' => false,
      ),
      'sqs' => 
      array (
        'driver' => 'sqs',
        'key' => '',
        'secret' => '',
        'prefix' => 'https://sqs.us-east-1.amazonaws.com/your-account-id',
        'queue' => 'default',
        'suffix' => NULL,
        'region' => 'us-east-1',
        'after_commit' => false,
      ),
      'redis' => 
      array (
        'driver' => 'redis',
        'connection' => 'default',
        'queue' => 'default',
        'retry_after' => 90,
        'block_for' => NULL,
        'after_commit' => false,
      ),
    ),
    'batching' => 
    array (
      'database' => 'mysql',
      'table' => 'job_batches',
    ),
    'failed' => 
    array (
      'driver' => 'database-uuids',
      'database' => 'mysql',
      'table' => 'failed_jobs',
    ),
  ),
  'sanctum' => 
  array (
    'stateful' => 
    array (
      0 => 'localhost',
      1 => 'localhost:3000',
      2 => '127.0.0.1',
      3 => '127.0.0.1:8000',
      4 => '::1',
      5 => 'localhost',
    ),
    'guard' => 
    array (
      0 => 'web',
    ),
    'expiration' => NULL,
    'token_prefix' => '',
    'middleware' => 
    array (
      'verify_csrf_token' => 'App\\Http\\Middleware\\VerifyCsrfToken',
      'encrypt_cookies' => 'App\\Http\\Middleware\\EncryptCookies',
    ),
  ),
  'services' => 
  array (
    'mailgun' => 
    array (
      'domain' => NULL,
      'secret' => NULL,
      'endpoint' => 'api.mailgun.net',
      'scheme' => 'https',
    ),
    'postmark' => 
    array (
      'token' => NULL,
    ),
    'ses' => 
    array (
      'key' => '',
      'secret' => '',
      'region' => 'us-east-1',
    ),
  ),
  'session' => 
  array (
    'driver' => 'file',
    'lifetime' => '120',
    'expire_on_close' => false,
    'encrypt' => false,
    'files' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\framework/sessions',
    'connection' => NULL,
    'table' => 'sessions',
    'store' => NULL,
    'lottery' => 
    array (
      0 => 2,
      1 => 100,
    ),
    'cookie' => 'laravel_session',
    'path' => '/',
    'domain' => NULL,
    'secure' => NULL,
    'http_only' => true,
    'same_site' => 'lax',
  ),
  'sweetalert' => 
  array (
    'theme' => 'default',
    'cdn' => NULL,
    'alwaysLoadJS' => false,
    'neverLoadJS' => false,
    'timer' => 5000,
    'width' => '32rem',
    'height_auto' => true,
    'padding' => '1.25rem',
    'background' => '#fff',
    'animation' => 
    array (
      'enable' => false,
    ),
    'animatecss' => 'https://cdnjs.cloudflare.com/ajax/libs/animate.css/4.1.1/animate.min.css',
    'show_confirm_button' => true,
    'show_close_button' => false,
    'button_text' => 
    array (
      'confirm' => 'OK',
      'cancel' => 'Cancel',
    ),
    'toast_position' => 'top-end',
    'timer_progress_bar' => false,
    'middleware' => 
    array (
      'autoClose' => false,
      'toast_position' => 'top-end',
      'toast_close_button' => true,
      'timer' => 6000,
      'auto_display_error_messages' => true,
    ),
    'customClass' => 
    array (
      'container' => NULL,
      'popup' => NULL,
      'header' => NULL,
      'title' => NULL,
      'closeButton' => NULL,
      'icon' => NULL,
      'image' => NULL,
      'content' => NULL,
      'input' => NULL,
      'actions' => NULL,
      'confirmButton' => NULL,
      'cancelButton' => NULL,
      'footer' => NULL,
    ),
    'confirm_delete_confirm_button_text' => 'Yes, delete it!',
    'confirm_delete_confirm_button_color' => NULL,
    'confirm_delete_cancel_button_color' => '#d33',
    'confirm_delete_cancel_button_text' => 'Cancel',
    'confirm_delete_show_cancel_button' => true,
    'confirm_delete_show_close_button' => false,
    'confirm_delete_icon' => 'warning',
    'confirm_delete_show_loader_on_confirm' => true,
  ),
  'view' => 
  array (
    'paths' => 
    array (
      0 => 'C:\\Users\\yared\\Videos\\CourseEnroll\\resources\\views',
    ),
    'compiled' => 'C:\\Users\\yared\\Videos\\CourseEnroll\\storage\\framework\\views',
  ),
  'laravelchapa' => 
  array (
    'secretKey' => 'CHASECK_TEST-sb5vgMV1y5s7ysB9zCPWufzxQ2GMsDef',
  ),
  'flare' => 
  array (
    'key' => NULL,
    'flare_middleware' => 
    array (
      0 => 'Spatie\\FlareClient\\FlareMiddleware\\RemoveRequestIp',
      1 => 'Spatie\\FlareClient\\FlareMiddleware\\AddGitInformation',
      2 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddNotifierName',
      3 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddEnvironmentInformation',
      4 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddExceptionInformation',
      5 => 'Spatie\\LaravelIgnition\\FlareMiddleware\\AddDumps',
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddLogs' => 
      array (
        'maximum_number_of_collected_logs' => 200,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddQueries' => 
      array (
        'maximum_number_of_collected_queries' => 200,
        'report_query_bindings' => true,
      ),
      'Spatie\\LaravelIgnition\\FlareMiddleware\\AddJobs' => 
      array (
        'max_chained_job_reporting_depth' => 5,
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestBodyFields' => 
      array (
        'censor_fields' => 
        array (
          0 => 'password',
          1 => 'password_confirmation',
        ),
      ),
      'Spatie\\FlareClient\\FlareMiddleware\\CensorRequestHeaders' => 
      array (
        'headers' => 
        array (
          0 => 'API-KEY',
        ),
      ),
    ),
    'send_logs_as_events' => true,
  ),
  'ignition' => 
  array (
    'editor' => 'phpstorm',
    'theme' => 'auto',
    'enable_share_button' => true,
    'register_commands' => false,
    'solution_providers' => 
    array (
      0 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\BadMethodCallSolutionProvider',
      1 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\MergeConflictSolutionProvider',
      2 => 'Spatie\\Ignition\\Solutions\\SolutionProviders\\UndefinedPropertySolutionProvider',
      3 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\IncorrectValetDbCredentialsSolutionProvider',
      4 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingAppKeySolutionProvider',
      5 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\DefaultDbNameSolutionProvider',
      6 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\TableNotFoundSolutionProvider',
      7 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingImportSolutionProvider',
      8 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\InvalidRouteActionSolutionProvider',
      9 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\ViewNotFoundSolutionProvider',
      10 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\RunningLaravelDuskInProductionProvider',
      11 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingColumnSolutionProvider',
      12 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UnknownValidationSolutionProvider',
      13 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingMixManifestSolutionProvider',
      14 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingViteManifestSolutionProvider',
      15 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\MissingLivewireComponentSolutionProvider',
      16 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\UndefinedViewVariableSolutionProvider',
      17 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\GenericLaravelExceptionSolutionProvider',
      18 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\OpenAiSolutionProvider',
      19 => 'Spatie\\LaravelIgnition\\Solutions\\SolutionProviders\\SailNetworkSolutionProvider',
    ),
    'ignored_solution_providers' => 
    array (
    ),
    'enable_runnable_solutions' => NULL,
    'remote_sites_path' => 'C:\\Users\\yared\\Videos\\CourseEnroll',
    'local_sites_path' => '',
    'housekeeping_endpoint_prefix' => '_ignition',
    'settings_file_path' => '',
    'recorders' => 
    array (
      0 => 'Spatie\\LaravelIgnition\\Recorders\\DumpRecorder\\DumpRecorder',
      1 => 'Spatie\\LaravelIgnition\\Recorders\\JobRecorder\\JobRecorder',
      2 => 'Spatie\\LaravelIgnition\\Recorders\\LogRecorder\\LogRecorder',
      3 => 'Spatie\\LaravelIgnition\\Recorders\\QueryRecorder\\QueryRecorder',
    ),
    'open_ai_key' => NULL,
    'with_stack_frame_arguments' => true,
    'argument_reducers' => 
    array (
      0 => 'Spatie\\Backtrace\\Arguments\\Reducers\\BaseTypeArgumentReducer',
      1 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ArrayArgumentReducer',
      2 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StdClassArgumentReducer',
      3 => 'Spatie\\Backtrace\\Arguments\\Reducers\\EnumArgumentReducer',
      4 => 'Spatie\\Backtrace\\Arguments\\Reducers\\ClosureArgumentReducer',
      5 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeArgumentReducer',
      6 => 'Spatie\\Backtrace\\Arguments\\Reducers\\DateTimeZoneArgumentReducer',
      7 => 'Spatie\\Backtrace\\Arguments\\Reducers\\SymphonyRequestArgumentReducer',
      8 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\ModelArgumentReducer',
      9 => 'Spatie\\LaravelIgnition\\ArgumentReducers\\CollectionArgumentReducer',
      10 => 'Spatie\\Backtrace\\Arguments\\Reducers\\StringableArgumentReducer',
    ),
  ),
  'oembed' => 
  array (
    'amp' => false,
    'ignore_http_errors' => true,
    'options' => 
    array (
      'attributes' => 
      array (
        'width' => NULL,
        'height' => NULL,
      ),
      'html' => 
      array (
        'iframe' => 
        array (
          'sandbox' => 'allow-scripts allow-popups allow-same-origin allow-presentation',
          'layout' => 'responsive',
        ),
        'video' => 
        array (
          'controls' => 'controls',
          'layout' => 'responsive',
        ),
      ),
      'providers' => 
      array (
        'YouTube' => 
        array (
          'data' => 
          array (
            'width' => 560,
            'height' => 315,
          ),
          'html' => 
          array (
            'width' => 560,
            'height' => 315,
          ),
        ),
      ),
    ),
    'oembed_providers' => 
    array (
      'http://www.23hq.com/23/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.23hq\\.com/.*/photo/.*$|i',
        ),
      ),
      'https://api.abraia.me/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://store\\.abraia\\.me/.*$|i',
        ),
      ),
      'https://secure.actblue.com/cf/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://secure\\.actblue\\.com/donate/.*$|i',
        ),
      ),
      'http://play.adpaths.com/oembed/*' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://play\\.adpaths\\.com/experience/.*$|i',
        ),
      ),
      'https://openapi.afreecatv.com/oembed/embedinfo' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://v\\.afree\\.ca/ST/$|i',
          1 => '|^https?://vod\\.afreecatv\\.com/ST/$|i',
          2 => '|^https?://vod\\.afreecatv\\.com/PLAYER/STATION/$|i',
          3 => '|^https?://play\\.afreecatv\\.com/$|i',
        ),
      ),
      'https://viewer.altium.com/shell/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://altium\\.com/viewer/.*$|i',
        ),
      ),
      'https://api.altrulabs.com/api/v1/social/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.altrulabs\\.com/.*/.*\\?answer_id\\=.*$|i',
          1 => '|^https?://app\\.altrulabs\\.com/player/.*$|i',
        ),
      ),
      'https://live.amcharts.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://live\\.amcharts\\.com/.*$|i',
          1 => '|^https?://live\\.amcharts\\.com/.*$|i',
        ),
      ),
      'https://animatron.com/oembed/json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.animatron\\.com/project/.*$|i',
          1 => '|^https?://animatron\\.com/project/.*$|i',
        ),
      ),
      'http://animoto.com/oembeds/create' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://animoto\\.com/play/.*$|i',
        ),
      ),
      'https://api.anniemusic.app/api/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://anniemusic\\.app/t/.*$|i',
          1 => '|^https?://anniemusic\\.app/p/.*$|i',
        ),
      ),
      'https://display.apester.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://renderer\\.apester\\.com/v2/.*\\?preview\\=true&iframe_preview\\=true$|i',
        ),
      ),
      'https://storymaps.arcgis.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://storymaps\\.arcgis\\.com/stories/.*$|i',
        ),
      ),
      'https://app.archivos.digital/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.archivos\\.digital/app/view/.*$|i',
        ),
      ),
      'https://audioboom.com/publishing/oembed/v4.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://audioboom\\.com/channels/.*$|i',
          1 => '|^https?://audioboom\\.com/channel/.*$|i',
          2 => '|^https?://audioboom\\.com/posts/.*$|i',
        ),
      ),
      'https://audioclip.naver.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://audioclip\\.naver\\.com/channels/.*/clips/.*$|i',
          1 => '|^https?://audioclip\\.naver\\.com/audiobooks/.*$|i',
        ),
      ),
      'https://audiomack.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://audiomack\\.com/.*/song/.*$|i',
          1 => '|^https?://audiomack\\.com/.*/album/.*$|i',
          2 => '|^https?://audiomack\\.com/.*/playlist/.*$|i',
        ),
      ),
      'https://podcasts.audiomeans.fr/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://podcasts\\.audiomeans\\.fr/.*$|i',
        ),
      ),
      'https://stage-embed.avocode.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.avocode\\.com/view/.*$|i',
        ),
      ),
      'https://backtracks.fm/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://backtracks\\.fm/.*/.*/e/.*$|i',
          1 => '|^https?://backtracks\\.fm/.*/s/.*/.*$|i',
          2 => '|^https?://backtracks\\.fm/.*/.*/.*/.*/e/.*/.*$|i',
          3 => '|^https?://backtracks\\.fm/.*$|i',
          4 => '|^https?://backtracks\\.fm/.*$|i',
        ),
      ),
      'https://blackfire.io/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://blackfire\\.io/profiles/.*/graph$|i',
          1 => '|^https?://blackfire\\.io/profiles/compare/.*/graph$|i',
        ),
      ),
      'https://blogcast.host/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://blogcast\\.host/embed/.*$|i',
          1 => '|^https?://blogcast\\.host/embedly/.*$|i',
        ),
      ),
      'https://view.briovr.com/api/v1/worlds/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://view\\.briovr\\.com/api/v1/worlds/oembed/.*$|i',
        ),
      ),
      'https://buttondown.email/embed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://buttondown\\.email/.*$|i',
        ),
      ),
      'https://cmc.byzart.eu/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://cmc\\.byzart\\.eu/files/.*$|i',
        ),
      ),
      'http://cacoo.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://cacoo\\.com/diagrams/.*$|i',
        ),
      ),
      'https://www.catapult.app/_hcms/api/video/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\-catapult\\-app\\.sandbox\\.hs\\-sites\\.com/video\\-page.*$|i',
          1 => '|^https?://www\\-catapult\\.app/video\\-page.*$|i',
        ),
      ),
      'http://img.catbo.at/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://img\\.catbo\\.at/.*$|i',
        ),
      ),
      'http://view.ceros.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://view\\.ceros\\.com/.*$|i',
        ),
      ),
      'https://www.chainflix.net/video/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://chainflix\\.net/video/.*$|i',
          1 => '|^https?://chainflix\\.net/video/embed/.*$|i',
          2 => '|^https?://.*\\.chainflix\\.net/video/.*$|i',
          3 => '|^https?://.*\\.chainflix\\.net/video/embed/.*$|i',
        ),
      ),
      'http://embed.chartblocks.com/1.0/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://public\\.chartblocks\\.com/c/.*$|i',
        ),
      ),
      'http://chirb.it/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://chirb\\.it/.*$|i',
        ),
      ),
      'https://chroco.ooo/embed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://chroco\\.ooo/mypage/.*$|i',
          1 => '|^https?://chroco\\.ooo/story/.*$|i',
        ),
      ),
      'https://www.circuitlab.com/circuit/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.circuitlab\\.com/circuit/.*$|i',
        ),
      ),
      'https://www.clipland.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.clipland\\.com/v/.*$|i',
          1 => '|^https?://www\\.clipland\\.com/v/.*$|i',
        ),
      ),
      'http://api.clyp.it/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://clyp\\.it/.*$|i',
          1 => '|^https?://clyp\\.it/playlist/.*$|i',
        ),
      ),
      'https://app.ilovecoco.video/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.ilovecoco\\.video/.*/embed$|i',
        ),
      ),
      'https://codehs.com/api/sharedprogram/*/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://codehs\\.com/editor/share_abacus/.*$|i',
        ),
      ),
      'https://codepen.io/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://codepen\\.io/.*$|i',
          1 => '|^https?://codepen\\.io/.*$|i',
        ),
      ),
      'https://codepoints.net/api/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://codepoints\\.net/.*$|i',
          1 => '|^https?://codepoints\\.net/.*$|i',
          2 => '|^https?://www\\.codepoints\\.net/.*$|i',
          3 => '|^https?://www\\.codepoints\\.net/.*$|i',
        ),
      ),
      'https://codesandbox.io/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://codesandbox\\.io/s/.*$|i',
          1 => '|^https?://codesandbox\\.io/embed/.*$|i',
        ),
      ),
      'http://www.collegehumor.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.collegehumor\\.com/video/.*$|i',
        ),
      ),
      'https://commaful.com/api/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://commaful\\.com/play/.*$|i',
        ),
      ),
      'http://coub.com/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://coub\\.com/view/.*$|i',
          1 => '|^https?://coub\\.com/embed/.*$|i',
        ),
      ),
      'http://crowdranking.com/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://crowdranking\\.com/.*/.*$|i',
        ),
      ),
      'https://crumb.sh/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://crumb\\.sh/.*$|i',
        ),
      ),
      'https://gql.cueup.io/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://cueup\\.io/user/.*/sounds/.*$|i',
        ),
      ),
      'https://api.curated.co/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.curated\\.co/.*$|i',
        ),
      ),
      'https://app.customerdb.com/embed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.customerdb\\.com/share/.*$|i',
        ),
      ),
      'https://www.dailymotion.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.dailymotion\\.com/video/.*$|i',
        ),
      ),
      'https://dalexni.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://dalexni\\.com/i/.*$|i',
        ),
      ),
      'https://api.datawrapper.de/v3/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://datawrapper\\.dwcdn\\.net/.*$|i',
        ),
      ),
      'https://embed.deseret.com/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.deseret\\.com/.*$|i',
        ),
      ),
      'http://backend.deviantart.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.deviantart\\.com/art/.*$|i',
          1 => '|^https?://.*\\.deviantart\\.com/.*\\#/d.*$|i',
          2 => '|^https?://fav\\.me/.*$|i',
          3 => '|^https?://sta\\.sh/.*$|i',
          4 => '|^https?://.*\\.deviantart\\.com/art/.*$|i',
          5 => '|^https?://.*\\.deviantart\\.com/.*/art/.*$|i',
          6 => '|^https?://sta\\.sh/.*",$|i',
          7 => '|^https?://.*\\.deviantart\\.com/.*\\#/d.*"$|i',
        ),
      ),
      'https://*.didacte.com/cards/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.didacte\\.com/a/course/.*$|i',
        ),
      ),
      'https://www.ultimedia.com/api/search/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.ultimedia\\.com/central/video/edit/id/.*/topic_id/.*/$|i',
          1 => '|^https?://www\\.ultimedia\\.com/default/index/videogeneric/id/.*/showtitle/1/viewnc/1$|i',
          2 => '|^https?://www\\.ultimedia\\.com/default/index/videogeneric/id/.*$|i',
        ),
      ),
      'https://www.docdroid.net/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.docdroid\\.net/.*$|i',
          1 => '|^https?://.*\\.docdroid\\.net/.*$|i',
          2 => '|^https?://docdro\\.id/.*$|i',
          3 => '|^https?://docdro\\.id/.*$|i',
          4 => '|^https?://.*\\.docdroid\\.com/.*$|i',
          5 => '|^https?://.*\\.docdroid\\.com/.*$|i',
        ),
      ),
      'http://dotsub.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://dotsub\\.com/view/.*$|i',
        ),
      ),
      'https://api.d.tube/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://d\\.tube/v/.*$|i',
        ),
      ),
      'http://egliseinfo.catholique.fr/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://egliseinfo\\.catholique\\.fr/.*$|i',
        ),
      ),
      'https://embedery.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://embedery\\.com/widget/.*$|i',
        ),
      ),
      'https://music.enystre.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://music\\.enystre\\.com/lyrics/.*$|i',
        ),
      ),
      'https://ethfiddle.com/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://ethfiddle\\.com/.*$|i',
        ),
      ),
      'https://evt.live/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://evt\\.live/.*$|i',
          1 => '|^https?://evt\\.live/.*/.*$|i',
          2 => '|^https?://live\\.eventlive\\.pro/.*$|i',
          3 => '|^https?://live\\.eventlive\\.pro/.*/.*$|i',
        ),
      ),
      'https://oembed.ex.co/item' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.ex\\.co/stories/.*$|i',
          1 => '|^https?://www\\.playbuzz\\.com/.*$|i',
        ),
      ),
      'https://eyrie.io/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://eyrie\\.io/board/.*$|i',
          1 => '|^https?://eyrie\\.io/sparkfun/.*$|i',
        ),
      ),
      'https://graph.facebook.com/v10.0/oembed_post' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.facebook\\.com/.*/posts/.*$|i',
          1 => '|^https?://www\\.facebook\\.com/.*/activity/.*$|i',
          2 => '|^https?://www\\.facebook\\.com/.*/photos/.*$|i',
          3 => '|^https?://www\\.facebook\\.com/photo\\.php\\?fbid\\=.*$|i',
          4 => '|^https?://www\\.facebook\\.com/photos/.*$|i',
          5 => '|^https?://www\\.facebook\\.com/permalink\\.php\\?story_fbid\\=.*$|i',
          6 => '|^https?://www\\.facebook\\.com/media/set\\?set\\=.*$|i',
          7 => '|^https?://www\\.facebook\\.com/questions/.*$|i',
          8 => '|^https?://www\\.facebook\\.com/notes/.*/.*/.*$|i',
        ),
      ),
      'https://graph.facebook.com/v10.0/oembed_video' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.facebook\\.com/.*/videos/.*$|i',
          1 => '|^https?://www\\.facebook\\.com/video\\.php\\?id\\=.*$|i',
          2 => '|^https?://www\\.facebook\\.com/video\\.php\\?v\\=.*$|i',
        ),
      ),
      'https://graph.facebook.com/v10.0/oembed_page' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.facebook\\.com/.*$|i',
        ),
      ),
      'https://app.getfader.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.getfader\\.com/projects/.*/publish$|i',
        ),
      ),
      'https://faithlifetv.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://faithlifetv\\.com/items/.*$|i',
          1 => '|^https?://faithlifetv\\.com/items/resource/.*/.*$|i',
          2 => '|^https?://faithlifetv\\.com/media/.*$|i',
          3 => '|^https?://faithlifetv\\.com/media/assets/.*$|i',
          4 => '|^https?://faithlifetv\\.com/media/resource/.*/.*$|i',
        ),
      ),
      'https://www.fireworktv.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.fireworktv\\.com/.*$|i',
          1 => '|^https?://.*\\.fireworktv\\.com/embed/.*/v/.*$|i',
        ),
      ),
      'https://www.fite.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.fite\\.tv/watch/.*$|i',
        ),
      ),
      'https://flat.io/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://flat\\.io/score/.*$|i',
          1 => '|^https?://.*\\.flat\\.io/score/.*$|i',
        ),
      ),
      'https://www.flickr.com/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.flickr\\.com/photos/.*$|i',
          1 => '|^https?://flic\\.kr/p/.*$|i',
          2 => '|^https?://.*\\.flickr\\.com/photos/.*$|i',
          3 => '|^https?://flic\\.kr/p/.*$|i',
          4 => '|^https?://.*\\..*\\.flickr\\.com/.*/.*$|i',
          5 => '|^https?://.*\\..*\\.flickr\\.com/.*/.*$|i',
        ),
      ),
      'https://app.flourish.studio/api/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://public\\.flourish\\.studio/visualisation/.*$|i',
          1 => '|^https?://public\\.flourish\\.studio/story/.*$|i',
        ),
      ),
      'https://fiso.foxsports.com.au/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://fiso\\.foxsports\\.com\\.au/isomorphic\\-widget/.*$|i',
          1 => '|^https?://fiso\\.foxsports\\.com\\.au/isomorphic\\-widget/.*$|i',
        ),
      ),
      'https://framebuzz.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://framebuzz\\.com/v/.*$|i',
          1 => '|^https?://framebuzz\\.com/v/.*$|i',
        ),
      ),
      'https://api.framer.com/web/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://framer\\.com/share/.*$|i',
          1 => '|^https?://framer\\.com/embed/.*$|i',
        ),
      ),
      'http://api.geograph.org.uk/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.geograph\\.org\\.uk/.*$|i',
          1 => '|^https?://.*\\.geograph\\.co\\.uk/.*$|i',
          2 => '|^https?://.*\\.geograph\\.ie/.*$|i',
          3 => '|^https?://.*\\.wikimedia\\.org/.*_geograph\\.org\\.uk_.*$|i',
        ),
      ),
      'http://www.geograph.org.gg/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.geograph\\.org\\.gg/.*$|i',
          1 => '|^https?://.*\\.geograph\\.org\\.je/.*$|i',
          2 => '|^https?://channel\\-islands\\.geograph\\.org/.*$|i',
          3 => '|^https?://channel\\-islands\\.geographs\\.org/.*$|i',
          4 => '|^https?://.*\\.channel\\.geographs\\.org/.*$|i',
        ),
      ),
      'http://geo.hlipp.de/restapi.php/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://geo\\-en\\.hlipp\\.de/.*$|i',
          1 => '|^https?://geo\\.hlipp\\.de/.*$|i',
          2 => '|^https?://germany\\.geograph\\.org/.*$|i',
        ),
      ),
      'http://embed.gettyimages.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://gty\\.im/.*$|i',
        ),
      ),
      'https://api.gfycat.com/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://gfycat\\.com/.*$|i',
          1 => '|^https?://www\\.gfycat\\.com/.*$|i',
          2 => '|^https?://gfycat\\.com/.*$|i',
          3 => '|^https?://www\\.gfycat\\.com/.*$|i',
        ),
      ),
      'https://www.gifnote.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.gifnote\\.com/play/.*$|i',
        ),
      ),
      'https://giphy.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://giphy\\.com/gifs/.*$|i',
          1 => '|^https?://giphy\\.com/clips/.*$|i',
          2 => '|^https?://gph\\.is/.*$|i',
          3 => '|^https?://media\\.giphy\\.com/media/.*/giphy\\.gif$|i',
        ),
      ),
      'https://app.gong.io/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.gong\\.io/call\\?id\\=.*$|i',
        ),
      ),
      'http://api.grain.co/_/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://grain\\.co/highlight/.*$|i',
        ),
      ),
      'https://api.luminery.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://gtchannel\\.com/watch/.*$|i',
        ),
      ),
      'https://api.gyazo.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://gyazo\\.com/.*$|i',
        ),
      ),
      'https://hearthis.at/oembed/?format=json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://hearthis\\.at/.*/.*/$|i',
          1 => '|^https?://hearthis\\.at/.*/set/.*/$|i',
        ),
      ),
      'https://player.hihaho.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://player\\.hihaho\\.com/.*$|i',
        ),
      ),
      'https://www.hippovideo.io/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.hippovideo\\.io/.*$|i',
          1 => '|^https?://.*\\.hippovideo\\.io/.*$|i',
        ),
      ),
      'https://homey.app/api/oembed/flow' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://homey\\.app/f/.*$|i',
          1 => '|^https?://homey\\.app/.*/flow/.*$|i',
        ),
      ),
      'http://huffduffer.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://huffduffer\\.com/.*/.*$|i',
        ),
      ),
      'http://www.hulu.com/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.hulu\\.com/watch/.*$|i',
        ),
      ),
      'https://oembed.idomoo.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.idomoo\\.com/.*$|i',
        ),
      ),
      'http://www.ifixit.com/Embed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.ifixit\\.com/Guide/View/.*$|i',
        ),
      ),
      'http://www.ifttt.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://ifttt\\.com/recipes/.*$|i',
        ),
      ),
      'https://www.iheart.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.iheart\\.com/podcast/.*/.*$|i',
        ),
      ),
      'https://player.indacolive.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://player\\.indacolive\\.com/player/jwp/clients/.*$|i',
        ),
      ),
      'https://infogram.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://infogram\\.com/.*$|i',
        ),
      ),
      'https://infoveave.net/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.infoveave\\.net/E/.*$|i',
          1 => '|^https?://.*\\.infoveave\\.net/P/.*$|i',
        ),
      ),
      'https://www.injurymap.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.injurymap\\.com/exercises/.*$|i',
        ),
      ),
      'https://www.inoreader.com/oembed/api/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.inoreader\\.com/oembed/$|i',
        ),
      ),
      'http://api.inphood.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.inphood\\.com/.*$|i',
        ),
      ),
      'https://graph.facebook.com/v10.0/instagram_oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://instagram\\.com/.*/p/.*,$|i',
          1 => '|^https?://www\\.instagram\\.com/.*/p/.*,$|i',
          2 => '|^https?://instagram\\.com/.*/p/.*,$|i',
          3 => '|^https?://www\\.instagram\\.com/.*/p/.*,$|i',
          4 => '|^https?://instagram\\.com/p/.*$|i',
          5 => '|^https?://instagr\\.am/p/.*$|i',
          6 => '|^https?://www\\.instagram\\.com/p/.*$|i',
          7 => '|^https?://www\\.instagr\\.am/p/.*$|i',
          8 => '|^https?://instagram\\.com/p/.*$|i',
          9 => '|^https?://instagr\\.am/p/.*$|i',
          10 => '|^https?://www\\.instagram\\.com/p/.*$|i',
          11 => '|^https?://www\\.instagr\\.am/p/.*$|i',
          12 => '|^https?://instagram\\.com/tv/.*$|i',
          13 => '|^https?://instagr\\.am/tv/.*$|i',
          14 => '|^https?://www\\.instagram\\.com/tv/.*$|i',
          15 => '|^https?://www\\.instagr\\.am/tv/.*$|i',
          16 => '|^https?://instagram\\.com/tv/.*$|i',
          17 => '|^https?://instagr\\.am/tv/.*$|i',
          18 => '|^https?://www\\.instagram\\.com/tv/.*$|i',
          19 => '|^https?://www\\.instagr\\.am/tv/.*$|i',
          20 => '|^https?://www\\.instagram\\.com/reel/.*$|i',
          21 => '|^https?://www\\.instagram\\.com/reel/.*$|i',
          22 => '|^https?://instagram\\.com/reel/.*$|i',
          23 => '|^https?://instagram\\.com/reel/.*$|i',
          24 => '|^https?://instagr\\.am/reel/.*$|i',
          25 => '|^https?://instagr\\.am/reel/.*$|i',
        ),
      ),
      'https://www.insticator.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://ppa\\.insticator\\.com/embed\\-unit/.*$|i',
        ),
      ),
      'https://issuu.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://issuu\\.com/.*/docs/.*$|i',
        ),
      ),
      'https://api.jovian.ai/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://jovian\\.ml/.*$|i',
          1 => '|^https?://jovian\\.ml/viewer.*$|i',
          2 => '|^https?://.*\\.jovian\\.ml/.*$|i',
          3 => '|^https?://jovian\\.ai/.*$|i',
          4 => '|^https?://jovian\\.ai/viewer.*$|i',
          5 => '|^https?://.*\\.jovian\\.ai/.*$|i',
        ),
      ),
      'https://tv.kakao.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://tv\\.kakao\\.com/channel/.*/cliplink/.*$|i',
          1 => '|^https?://tv\\.kakao\\.com/m/channel/.*/cliplink/.*$|i',
          2 => '|^https?://tv\\.kakao\\.com/channel/v/.*$|i',
          3 => '|^https?://tv\\.kakao\\.com/channel/.*/livelink/.*$|i',
          4 => '|^https?://tv\\.kakao\\.com/m/channel/.*/livelink/.*$|i',
          5 => '|^https?://tv\\.kakao\\.com/channel/l/.*$|i',
        ),
      ),
      'http://www.kickstarter.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.kickstarter\\.com/projects/.*$|i',
        ),
      ),
      'https://www.kidoju.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.kidoju\\.com/en/x/.*/.*$|i',
          1 => '|^https?://www\\.kidoju\\.com/fr/x/.*/.*$|i',
        ),
      ),
      'https://halaman.email/service/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://halaman\\.email/form/.*$|i',
          1 => '|^https?://aplikasi\\.kirim\\.email/form/.*$|i',
        ),
      ),
      'https://embed.kit.co/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://kit\\.co/.*/.*$|i',
          1 => '|^https?://kit\\.co/.*/.*$|i',
        ),
      ),
      'http://www.kitchenbowl.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.kitchenbowl\\.com/recipe/.*$|i',
        ),
      ),
      'https://api.kmdr.sh/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.kmdr\\.sh/h/.*$|i',
          1 => '|^https?://app\\.kmdr\\.sh/history/.*$|i',
        ),
      ),
      'https://jdr.knacki.info/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://jdr\\.knacki\\.info/meuh/.*$|i',
          1 => '|^https?://jdr\\.knacki\\.info/meuh/.*$|i',
        ),
      ),
      'https://api.spoonacular.com/knowledge/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://knowledgepad\\.co/\\#/knowledge/.*$|i',
        ),
      ),
      'https://embed-stage.kooapp.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.kooapp\\.com/koo/$|i',
          1 => '|^https?://.*\\.kooapp\\.com/koo/$|i',
        ),
      ),
      'http://learningapps.org/oembed.php' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://learningapps\\.org/.*$|i',
        ),
      ),
      'https://umotion-test.univ-lemans.fr/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://umotion\\-test\\.univ\\-lemans\\.fr/video/.*$|i',
        ),
      ),
      'https://pod.univ-lille.fr/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://pod\\.univ\\-lille\\.fr/video/.*$|i',
        ),
      ),
      'https://livestream.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://livestream\\.com/accounts/.*/events/.*$|i',
          1 => '|^https?://livestream\\.com/accounts/.*/events/.*/videos/.*$|i',
          2 => '|^https?://livestream\\.com/.*/events/.*$|i',
          3 => '|^https?://livestream\\.com/.*/events/.*/videos/.*$|i',
          4 => '|^https?://livestream\\.com/.*/.*$|i',
          5 => '|^https?://livestream\\.com/.*/.*/videos/.*$|i',
        ),
      ),
      'https://embed.lottiefiles.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://lottiefiles\\.com/.*$|i',
          1 => '|^https?://.*\\.lottiefiles\\.com/.*$|i',
        ),
      ),
      'https://app.ludus.one/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.ludus\\.one/.*$|i',
        ),
      ),
      'https://admin.lumiere.is/api/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.lumiere\\.is/v/.*$|i',
        ),
      ),
      'http://mathembed.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://mathembed\\.com/latex\\?inputText\\=.*$|i',
          1 => '|^https?://mathembed\\.com/latex\\?inputText\\=.*$|i',
        ),
      ),
      'https://me.me/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://me\\.me/i/.*$|i',
        ),
      ),
      'https://*.medialab.(co|app)/api/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.medialab\\.app/share/watch/.*$|i',
          1 => '|^https?://.*\\.medialab\\.co/share/watch/.*$|i',
          2 => '|^https?://.*\\.medialab\\.app/share/social/.*$|i',
          3 => '|^https?://.*\\.medialab\\.co/share/social/.*$|i',
          4 => '|^https?://.*\\.medialab\\.app/share/embed/.*$|i',
          5 => '|^https?://.*\\.medialab\\.co/share/embed/.*$|i',
        ),
      ),
      'https://medienarchiv.zhdk.ch/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://medienarchiv\\.zhdk\\.ch/entries/.*$|i',
        ),
      ),
      'https://mermaid.ink/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://mermaid\\.ink/img/.*$|i',
          1 => '|^https?://mermaid\\.ink/svg/.*$|i',
        ),
      ),
      'https://web.microsoftstream.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.microsoftstream\\.com/video/.*$|i',
          1 => '|^https?://.*\\.microsoftstream\\.com/channel/.*$|i',
        ),
      ),
      'https://oembed.minervaknows.com' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.minervaknows\\.com/featured\\-recipes/.*$|i',
          1 => '|^https?://www\\.minervaknows\\.com/themes/.*$|i',
          2 => '|^https?://www\\.minervaknows\\.com/themes/.*/recipes/.*$|i',
          3 => '|^https?://app\\.minervaknows\\.com/recipes/.*$|i',
          4 => '|^https?://app\\.minervaknows\\.com/recipes/.*/follow$|i',
        ),
      ),
      'https://www.mixcloud.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.mixcloud\\.com/.*/.*/$|i',
          1 => '|^https?://www\\.mixcloud\\.com/.*/.*/$|i',
        ),
      ),
      'http://api.mobypicture.com/oEmbed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.mobypicture\\.com/user/.*/view/.*$|i',
          1 => '|^https?://moby\\.to/.*$|i',
        ),
      ),
      'https://musicboxmaniacs.com/embed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://musicboxmaniacs\\.com/explore/melody/.*$|i',
        ),
      ),
      'https://mybeweeg.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://mybeweeg\\.com/w/.*$|i',
        ),
      ),
      'https://namchey.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://namchey\\.com/embeds/.*$|i',
        ),
      ),
      'https://www.nanoo.tv/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.nanoo\\.tv/link/.*$|i',
          1 => '|^https?://nanoo\\.tv/link/.*$|i',
          2 => '|^https?://.*\\.nanoo\\.pro/link/.*$|i',
          3 => '|^https?://nanoo\\.pro/link/.*$|i',
          4 => '|^https?://.*\\.nanoo\\.tv/link/.*$|i',
          5 => '|^https?://nanoo\\.tv/link/.*$|i',
          6 => '|^https?://.*\\.nanoo\\.pro/link/.*$|i',
          7 => '|^https?://nanoo\\.pro/link/.*$|i',
          8 => '|^https?://media\\.zhdk\\.ch/signatur/.*$|i',
          9 => '|^https?://new\\.media\\.zhdk\\.ch/signatur/.*$|i',
          10 => '|^https?://media\\.zhdk\\.ch/signatur/.*$|i',
          11 => '|^https?://new\\.media\\.zhdk\\.ch/signatur/.*$|i',
        ),
      ),
      'https://api.nb.no/catalog/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.nb\\.no/items/.*$|i',
        ),
      ),
      'https://naturalatlas.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://naturalatlas\\.com/.*$|i',
          1 => '|^https?://naturalatlas\\.com/.*/.*$|i',
          2 => '|^https?://naturalatlas\\.com/.*/.*/.*$|i',
          3 => '|^https?://naturalatlas\\.com/.*/.*/.*/.*$|i',
        ),
      ),
      'http://www.nfb.ca/remote/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.nfb\\.ca/film/.*$|i',
        ),
      ),
      'https://oembed.nopaste.ml' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://nopaste\\.ml/.*$|i',
        ),
      ),
      'https://api.observablehq.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://observablehq\\.com/@.*/.*$|i',
          1 => '|^https?://observablehq\\.com/d/.*$|i',
          2 => '|^https?://observablehq\\.com/embed/.*$|i',
        ),
      ),
      'https://www.odds.com.au/api/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.odds\\.com\\.au/.*$|i',
          1 => '|^https?://odds\\.com\\.au/.*$|i',
        ),
      ),
      'https://song.link/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://song\\.link/.*$|i',
          1 => '|^https?://album\\.link/.*$|i',
          2 => '|^https?://artist\\.link/.*$|i',
          3 => '|^https?://playlist\\.link/.*$|i',
          4 => '|^https?://pods\\.link/.*$|i',
          5 => '|^https?://mylink\\.page/.*$|i',
          6 => '|^https?://odesli\\.co/.*$|i',
        ),
      ),
      'https://odysee.com/$/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://odysee\\.com/.*/.*$|i',
          1 => '|^https?://odysee\\.com/.*$|i',
        ),
      ),
      'http://official.fm/services/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://official\\.fm/tracks/.*$|i',
          1 => '|^https?://official\\.fm/playlists/.*$|i',
        ),
      ),
      'https://omniscope.me/_global_/oembed/json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://omniscope\\.me/.*$|i',
        ),
      ),
      'https://omny.fm/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://omny\\.fm/shows/.*$|i',
        ),
      ),
      'http://orbitvu.co/service/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://orbitvu\\.co/001/.*/ov3601/view$|i',
          1 => '|^https?://orbitvu\\.co/001/.*/ov3601/.*/view$|i',
          2 => '|^https?://orbitvu\\.co/001/.*/ov3602/.*/view$|i',
          3 => '|^https?://orbitvu\\.co/001/.*/2/orbittour/.*/view$|i',
          4 => '|^https?://orbitvu\\.co/001/.*/1/2/orbittour/.*/view$|i',
          5 => '|^https?://orbitvu\\.co/001/.*/ov3601/view$|i',
          6 => '|^https?://orbitvu\\.co/001/.*/ov3601/.*/view$|i',
          7 => '|^https?://orbitvu\\.co/001/.*/ov3602/.*/view$|i',
          8 => '|^https?://orbitvu\\.co/001/.*/2/orbittour/.*/view$|i',
          9 => '|^https?://orbitvu\\.co/001/.*/1/2/orbittour/.*/view$|i',
        ),
      ),
      'https://outplayed.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://outplayed\\.tv/media/.*$|i',
        ),
      ),
      'https://overflow.io/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://overflow\\.io/s/.*$|i',
          1 => '|^https?://overflow\\.io/embed/.*$|i',
        ),
      ),
      'https://core.oz.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.oz\\.com/.*/video/.*$|i',
        ),
      ),
      'https://padlet.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://padlet\\.com/.*$|i',
        ),
      ),
      'https://www.pastery.net/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://pastery\\.net/.*$|i',
          1 => '|^https?://pastery\\.net/.*$|i',
          2 => '|^https?://www\\.pastery\\.net/.*$|i',
          3 => '|^https?://www\\.pastery\\.net/.*$|i',
        ),
      ),
      'https://tools.pinpoll.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://tools\\.pinpoll\\.com/embed/.*$|i',
        ),
      ),
      'https://www.pinterest.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.pinterest\\.com/.*$|i',
        ),
      ),
      'https://*.pitchhub.com.com/en/public/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.pitchhub\\.com/en/public/player/.*$|i',
        ),
      ),
      'https://store.pixdor.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://store\\.pixdor\\.com/place\\-marker\\-widget/.*/show$|i',
          1 => '|^https?://store\\.pixdor\\.com/map/.*/show$|i',
        ),
      ),
      'https://api.podbean.com/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.podbean\\.com/e/.*$|i',
          1 => '|^https?://.*\\.podbean\\.com/e/.*$|i',
        ),
      ),
      'http://polldaddy.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.polldaddy\\.com/s/.*$|i',
          1 => '|^https?://.*\\.polldaddy\\.com/poll/.*$|i',
          2 => '|^https?://.*\\.polldaddy\\.com/ratings/.*$|i',
        ),
      ),
      'https://api.portfolium.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://portfolium\\.com/entry/.*$|i',
        ),
      ),
      'https://gateway.cobalt.run/present/decks/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://present\\.do/decks/.*$|i',
        ),
      ),
      'https://prezi.com/v/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://prezi\\.com/v/.*$|i',
          1 => '|^https?://.*\\.prezi\\.com/v/.*$|i',
        ),
      ),
      'http://www.quiz.biz/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.quiz\\.biz/quizz\\-.*\\.html$|i',
        ),
      ),
      'http://www.quizz.biz/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.quizz\\.biz/quizz\\-.*\\.html$|i',
        ),
      ),
      'https://oembed.radiopublic.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://play\\.radiopublic\\.com/.*$|i',
          1 => '|^https?://radiopublic\\.com/.*$|i',
          2 => '|^https?://www\\.radiopublic\\.com/.*$|i',
          3 => '|^https?://play\\.radiopublic\\.com/.*$|i',
          4 => '|^https?://radiopublic\\.com/.*$|i',
          5 => '|^https?://www\\.radiopublic\\.com/.*$|i',
          6 => '|^https?://.*\\.radiopublic\\.com/.*$|i',
        ),
      ),
      'https://pub.raindrop.io/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://raindrop\\.io/.*$|i',
          1 => '|^https?://raindrop\\.io/.*/.*$|i',
          2 => '|^https?://raindrop\\.io/.*/.*/.*$|i',
          3 => '|^https?://raindrop\\.io/.*/.*/.*/.*$|i',
        ),
      ),
      'https://animatron.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.rcvis\\.com/v/.*$|i',
          1 => '|^https?://www\\.rcvis\\.com/visualize\\=.*$|i',
          2 => '|^https?://www\\.rcvis\\.com/ve/.*$|i',
          3 => '|^https?://www\\.rcvis\\.com/visualizeEmbedded\\=.*$|i',
        ),
      ),
      'https://www.reddit.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://reddit\\.com/r/.*/comments/.*/.*$|i',
          1 => '|^https?://www\\.reddit\\.com/r/.*/comments/.*/.*$|i',
        ),
      ),
      'http://publisher.releasewire.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://rwire\\.com/.*$|i',
        ),
      ),
      'https://replit.com/data/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://repl\\.it/@.*/.*$|i',
          1 => '|^https?://replit\\.com/@.*/.*$|i',
        ),
      ),
      'https://www.reverbnation.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.reverbnation\\.com/.*$|i',
          1 => '|^https?://www\\.reverbnation\\.com/.*/songs/.*$|i',
        ),
      ),
      'http://roomshare.jp/en/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://roomshare\\.jp/post/.*$|i',
          1 => '|^https?://roomshare\\.jp/en/post/.*$|i',
        ),
      ),
      'https://roosterteeth.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://roosterteeth\\.com/.*$|i',
        ),
      ),
      'https://embed.runkit.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://embed\\.runkit\\.com/.*,$|i',
          1 => '|^https?://embed\\.runkit\\.com/.*,$|i',
        ),
      ),
      'https://octopus.saooti.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://octopus\\.saooti\\.com/main/pub/podcast/.*$|i',
        ),
      ),
      'http://videos.sapo.pt/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://videos\\.sapo\\.pt/.*$|i',
        ),
      ),
      'https://api.screen9.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://console\\.screen9\\.com/.*$|i',
          1 => '|^https?://.*\\.screen9\\.tv/.*$|i',
        ),
      ),
      'https://api.screencast.com/external/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.screencast\\.com/.*$|i',
        ),
      ),
      'http://www.screenr.com/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.screenr\\.com/.*/$|i',
        ),
      ),
      'https://scribblemaps.com/api/services/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.scribblemaps\\.com/maps/view/.*$|i',
          1 => '|^https?://www\\.scribblemaps\\.com/maps/view/.*$|i',
          2 => '|^https?://scribblemaps\\.com/maps/view/.*$|i',
          3 => '|^https?://scribblemaps\\.com/maps/view/.*$|i',
        ),
      ),
      'http://www.scribd.com/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.scribd\\.com/doc/.*$|i',
        ),
      ),
      'https://embed.sendtonews.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://embed\\.sendtonews\\.com/oembed/.*$|i',
        ),
      ),
      'https://www.shortnote.jp/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.shortnote\\.jp/view/notes/.*$|i',
        ),
      ),
      'http://shoudio.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://shoudio\\.com/.*$|i',
          1 => '|^https?://shoud\\.io/.*$|i',
        ),
      ),
      'https://api.getshow.io/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.getshow\\.io/iframe/.*$|i',
          1 => '|^https?://.*\\.getshow\\.io/share/.*$|i',
        ),
      ),
      'https://showtheway.io/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://showtheway\\.io/to/.*$|i',
        ),
      ),
      'https://simplecast.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://simplecast\\.com/s/.*$|i',
        ),
      ),
      'https://onsizzle.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://onsizzle\\.com/i/.*$|i',
        ),
      ),
      'http://sketchfab.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://sketchfab\\.com/.*models/.*$|i',
          1 => '|^https?://sketchfab\\.com/.*models/.*$|i',
          2 => '|^https?://sketchfab\\.com/.*/folders/.*$|i',
        ),
      ),
      'https://www.slideshare.net/api/oembed/2' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.slideshare\\.net/.*/.*$|i',
          1 => '|^https?://www\\.slideshare\\.net/.*/.*$|i',
          2 => '|^https?://fr\\.slideshare\\.net/.*/.*$|i',
          3 => '|^https?://fr\\.slideshare\\.net/.*/.*$|i',
          4 => '|^https?://de\\.slideshare\\.net/.*/.*$|i',
          5 => '|^https?://de\\.slideshare\\.net/.*/.*$|i',
          6 => '|^https?://es\\.slideshare\\.net/.*/.*$|i',
          7 => '|^https?://es\\.slideshare\\.net/.*/.*$|i',
          8 => '|^https?://pt\\.slideshare\\.net/.*/.*$|i',
          9 => '|^https?://pt\\.slideshare\\.net/.*/.*$|i',
        ),
      ),
      'https://smashnotes.com/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://smashnotes\\.com/p/.*$|i',
          1 => '|^https?://smashnotes\\.com/p/.*/e/.* \\- https?://smashnotes\\.com/p/.*/e/.*/s/.*$|i',
        ),
      ),
      'https://www.smrthi.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.smrthi\\.com/book/.*$|i',
        ),
      ),
      'https://api.smugmug.com/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.smugmug\\.com/.*$|i',
          1 => '|^https?://.*\\.smugmug\\.com/.*$|i',
        ),
      ),
      'https://www.socialexplorer.com/services/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.socialexplorer\\.com/.*/explore$|i',
          1 => '|^https?://www\\.socialexplorer\\.com/.*/view$|i',
          2 => '|^https?://www\\.socialexplorer\\.com/.*/edit$|i',
          3 => '|^https?://www\\.socialexplorer\\.com/.*/embed$|i',
        ),
      ),
      'https://soundcloud.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://soundcloud\\.com/.*$|i',
          1 => '|^https?://soundcloud\\.com/.*$|i',
          2 => '|^https?://soundcloud\\.app\\.goog\\.gl/.*$|i',
        ),
      ),
      'https://speakerdeck.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://speakerdeck\\.com/.*/.*$|i',
          1 => '|^https?://speakerdeck\\.com/.*/.*$|i',
        ),
      ),
      'https://open.spotify.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://open\\.spotify\\.com/.*$|i',
          1 => '|^spotify:.*$|i',
        ),
      ),
      'https://api.spreaker.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.spreaker\\.com/.*$|i',
          1 => '|^https?://.*\\.spreaker\\.com/.*$|i',
        ),
      ),
      'http://sproutvideo.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://sproutvideo\\.com/videos/.*$|i',
          1 => '|^https?://.*\\.vids\\.io/videos/.*$|i',
        ),
      ),
      'https://purl.stanford.edu/embed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://purl\\.stanford\\.edu/.*$|i',
        ),
      ),
      'https://api.streamable.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://streamable\\.com/.*$|i',
          1 => '|^https?://streamable\\.com/.*$|i',
        ),
      ),
      'https://streamio.com/api/v1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://s3m\\.io/.*$|i',
          1 => '|^https?://23m\\.io/.*$|i',
        ),
      ),
      'https://subscribi.io/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://subscribi\\.io/api/oembed.*$|i',
        ),
      ),
      'https://www.sudomemo.net/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.sudomemo\\.net/watch/.*$|i',
          1 => '|^https?://www\\.sudomemo\\.net/watch/.*$|i',
          2 => '|^https?://flipnot\\.es/.*$|i',
          3 => '|^https?://flipnot\\.es/.*$|i',
        ),
      ),
      'https://www.sutori.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.sutori\\.com/story/.*$|i',
        ),
      ),
      'https://sway.com/api/v1.0/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://sway\\.com/.*$|i',
          1 => '|^https?://www\\.sway\\.com/.*$|i',
        ),
      ),
      'https://69jr5v75rc.execute-api.eu-west-1.amazonaws.com/prod/v2/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://share\\.synthesia\\.io/.*$|i',
        ),
      ),
      'https://www.ted.com/services/v1/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://ted\\.com/talks/.*$|i',
          1 => '|^https?://ted\\.com/talks/.*$|i',
          2 => '|^https?://www\\.ted\\.com/talks/.*$|i',
        ),
      ),
      'https://www.nytimes.com/svc/oembed/json/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.nytimes\\.com/svc/oembed$|i',
          1 => '|^https?://nytimes\\.com/.*$|i',
          2 => '|^https?://.*\\.nytimes\\.com/.*$|i',
        ),
      ),
      'https://theysaidso.com/extensions/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://theysaidso\\.com/image/.*$|i',
        ),
      ),
      'https://www.tickcounter.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.tickcounter\\.com/countdown/.*$|i',
          1 => '|^https?://www\\.tickcounter\\.com/countup/.*$|i',
          2 => '|^https?://www\\.tickcounter\\.com/ticker/.*$|i',
          3 => '|^https?://www\\.tickcounter\\.com/worldclock/.*$|i',
          4 => '|^https?://www\\.tickcounter\\.com/countdown/.*$|i',
          5 => '|^https?://www\\.tickcounter\\.com/countup/.*$|i',
          6 => '|^https?://www\\.tickcounter\\.com/ticker/.*$|i',
          7 => '|^https?://www\\.tickcounter\\.com/worldclock/.*$|i',
        ),
      ),
      'https://www.tiktok.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.tiktok\\.com/.*/video/.*$|i',
        ),
      ),
      'https://widget.toornament.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.toornament\\.com/tournaments/.*/information$|i',
          1 => '|^https?://www\\.toornament\\.com/tournaments/.*/registration/$|i',
          2 => '|^https?://www\\.toornament\\.com/tournaments/.*/matches/schedule$|i',
          3 => '|^https?://www\\.toornament\\.com/tournaments/.*/stages/.*/$|i',
        ),
      ),
      'http://www.topy.se/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.topy\\.se/image/.*$|i',
        ),
      ),
      'https://app-test.totango.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\-test\\.totango\\.com/.*$|i',
        ),
      ),
      'https://trinitymedia.ai/player/trinity-oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://trinitymedia\\.ai/player/.*$|i',
          1 => '|^https?://trinitymedia\\.ai/player/.*$|i',
        ),
      ),
      'https://www.tumblr.com/oembed/1.0' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.tumblr\\.com/post/.*$|i',
        ),
      ),
      'https://www.tuxx.be/services/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.tuxx\\.be/.*$|i',
        ),
      ),
      'https://play.tvcf.co.kr/rest/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://play\\.tvcf\\.co\\.kr/.*$|i',
          1 => '|^https?://.*\\.tvcf\\.co\\.kr/.*$|i',
        ),
      ),
      'https://publish.twitter.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://twitter\\.com/.*$|i',
          1 => '|^https?://twitter\\.com/.*/status/.*$|i',
          2 => '|^https?://.*\\.twitter\\.com/.*/status/.*$|i',
        ),
      ),
      'https://play.typecast.ai/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://play\\.typecast\\.ai/s/.*$|i',
          1 => '|^https?://play\\.typecast\\.ai/e/.*$|i',
          2 => '|^https?://play\\.typecast\\.ai/.*$|i',
        ),
      ),
      'https://uapod.univ-antilles.fr/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://uapod\\.univ\\-antilles\\.fr/video/.*$|i',
        ),
      ),
      'https://map.cam.ac.uk/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://map\\.cam\\.ac\\.uk/.*$|i',
        ),
      ),
      'https://mediatheque.univ-paris1.fr/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://mediatheque\\.univ\\-paris1\\.fr/video/.*$|i',
        ),
      ),
      'https://pod.u-pec.fr/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://pod\\.u\\-pec\\.fr/video/.*$|i',
        ),
      ),
      'http://www.ustream.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.ustream\\.tv/.*$|i',
          1 => '|^https?://.*\\.ustream\\.com/.*$|i',
        ),
      ),
      'https://app.ustudio.com/api/v2/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.ustudio\\.com/embed/.*$|i',
          1 => '|^https?://.*\\.ustudio\\.com/embed/.*/.*$|i',
        ),
      ),
      'https://api.veer.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://veer\\.tv/videos/.*$|i',
        ),
      ),
      'https://api.veervr.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://veervr\\.tv/videos/.*$|i',
        ),
      ),
      'https://www.vevo.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.vevo\\.com/.*$|i',
          1 => '|^https?://www\\.vevo\\.com/.*$|i',
        ),
      ),
      'https://videfit.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://videfit\\.com/videos/.*$|i',
        ),
      ),
      'https://api.vidyard.com/dashboard/v1.1/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.vidyard\\.com/.*$|i',
          1 => '|^https?://.*\\.vidyard\\.com/.*$|i',
          2 => '|^https?://.*\\.hubs\\.vidyard\\.com/.*$|i',
          3 => '|^https?://.*\\.hubs\\.vidyard\\.com/.*$|i',
        ),
      ),
      'https://vimeo.com/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://vimeo\\.com/.*$|i',
          1 => '|^https?://vimeo\\.com/album/.*/video/.*$|i',
          2 => '|^https?://vimeo\\.com/channels/.*/.*$|i',
          3 => '|^https?://vimeo\\.com/groups/.*/videos/.*$|i',
          4 => '|^https?://vimeo\\.com/ondemand/.*/.*$|i',
          5 => '|^https?://player\\.vimeo\\.com/video/.*$|i',
        ),
      ),
      'https://www.viously.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.viously\\.com/.*/.*$|i',
        ),
      ),
      'https://vizydrop.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://vizydrop\\.com/shared/.*$|i',
        ),
      ),
      'https://vlipsy.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://vlipsy\\.com/.*$|i',
        ),
      ),
      'https://www.vlive.tv/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://www\\.vlive\\.tv/video/.*$|i',
        ),
      ),
      'https://data.voxsnap.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://article\\.voxsnap\\.com/.*/.*$|i',
        ),
      ),
      'https://waltrack.net/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://waltrack\\.net/product/.*$|i',
        ),
      ),
      'https://embed.wave.video/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://watch\\.wave\\.video/.*$|i',
          1 => '|^https?://embed\\.wave\\.video/.*$|i',
        ),
      ),
      'http://*.wiredrive.com/present-oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.wiredrive\\.com/.*$|i',
        ),
      ),
      'https://fast.wistia.com/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://fast\\.wistia\\.com/embed/iframe/.*$|i',
          1 => '|^https?://fast\\.wistia\\.com/embed/playlists/.*$|i',
          2 => '|^https?://.*\\.wistia\\.com/medias/.*$|i',
        ),
      ),
      'https://app.wizer.me/api/oembed.json' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.wizer\\.me/learn/.*$|i',
          1 => '|^https?://.*\\.wizer\\.me/preview/.*$|i',
        ),
      ),
      'https://wokwi.com/api/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://wokwi\\.com/share/.*$|i',
        ),
      ),
      'https://www.wolframcloud.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.wolframcloud\\.com/.*$|i',
        ),
      ),
      'http://public-api.wordpress.com/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://wordpress\\.com/.*$|i',
          1 => '|^https?://wordpress\\.com/.*$|i',
          2 => '|^https?://.*\\.wordpress\\.com/.*$|i',
          3 => '|^https?://.*\\.wordpress\\.com/.*$|i',
          4 => '|^https?://.*\\..*\\.wordpress\\.com/.*$|i',
          5 => '|^https?://.*\\..*\\.wordpress\\.com/.*$|i',
          6 => '|^https?://wp\\.me/.*$|i',
          7 => '|^https?://wp\\.me/.*$|i',
        ),
      ),
      'https://www.youtube.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.youtube\\.com/watch.*$|i',
          1 => '|^https?://.*\\.youtube\\.com/v/.*$|i',
          2 => '|^https?://youtu\\.be/.*$|i',
          3 => '|^https?://.*\\.youtube\\.com/playlist\\?list\\=.*$|i',
          4 => '|^https?://youtube\\.com/playlist\\?list\\=.*$|i',
        ),
      ),
      'https://app.zeplin.io/embed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.zeplin\\.io/project/.*/screen/.*$|i',
          1 => '|^https?://app\\.zeplin\\.io/project/.*/screen/.*/version/.*$|i',
          2 => '|^https?://app\\.zeplin\\.io/project/.*/styleguide/components\\?coid\\=.*$|i',
          3 => '|^https?://app\\.zeplin\\.io/styleguide/.*/components\\?coid\\=.*$|i',
        ),
      ),
      'https://app.zingsoft.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://app\\.zingsoft\\.com/embed/.*$|i',
          1 => '|^https?://app\\.zingsoft\\.com/view/.*$|i',
        ),
      ),
      'https://api.znipe.tv/v3/oembed/' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://.*\\.znipe\\.tv/.*$|i',
        ),
      ),
      'https://srv2.zoomable.ca/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://srv2\\.zoomable\\.ca/viewer\\.php.*$|i',
        ),
      ),
      'http://jsbin.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://output\\.jsbin\\.com/.*$|i',
          1 => '|^https?://jsbin\\.com/.*$|i',
        ),
      ),
      'https://api.crowdsignal.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://polldaddy\\.com/poll/.*$|i',
          1 => '|^https?://poll\\.fm/.*$|i',
        ),
      ),
      'https://api.imgur.com/oembed' => 
      array (
        'schemes' => 
        array (
          0 => '|^https?://imgur\\.com/.*$|i',
          1 => '|^https?://i\\.imgur\\.com/.*$|i',
        ),
      ),
    ),
    'regex_providers' => 
    array (
      'liveleak' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://(?:www\\.)?liveleak\\.com/ll_embed\\?f=([0-9a-z]+)~imu',
          1 => '~^https?://(?:www\\.)?liveleak\\.com/view\\?t=([0-9a-z_]+)~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'LiveLeak',
          'provider_url' => 'https://www.liveleak.com',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 640,
              'height' => 360,
              'src' => '{protocol}://liveleak.com/e/{1}',
            ),
          ),
        ),
      ),
      'ign' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://(?:www\\.)?ign\\.com/videos/([0-9a-zA-Z-_/]+)~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'IGN',
          'provider_url' => 'https://ign.com',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 560,
              'height' => 315,
              'src' => '{protocol}://widgets.ign.com/video/embed/content.html?url={1}',
            ),
          ),
        ),
      ),
      'vine' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://(?:www\\.)?vine\\.co/v/([0-9a-zA-Z]+)~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'Vine',
          'provider_url' => 'https://vine.co',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 600,
              'height' => 600,
              'src' => '{protocol}://vine.co/v/{1}/embed/postcard',
            ),
          ),
        ),
      ),
      'twitch' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://(?:www\\.)?twitch\\.tv/([0-9a-zA-Z-_]+)$~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'Twitch',
          'provider_url' => 'https://twitch.tv/{1}',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 500,
              'height' => 350,
              'src' => '{protocol}://player.twitch.tv/?channel={1}&parent=',
              'allowfullscreen' => NULL,
              'frameborder' => 0,
              'sandbox' => 'allow-scripts allow-popups allow-same-origin allow-presentation',
              'layout' => 'responsive',
            ),
          ),
        ),
      ),
      'twitchVideo' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://(?:www\\.)?twitch\\.tv/videos/(\\d+)$~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'Twitch Videos',
          'provider_url' => 'https://twitch.tv/videos/{1}',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 600,
              'height' => 365,
              'src' => '{protocol}://player.twitch.tv/?video=v{1}&autoplay=false&parent=www.example.com',
              'allowfullscreen' => NULL,
              'frameborder' => 0,
              'sandbox' => 'allow-scripts allow-popups allow-same-origin allow-presentation',
              'layout' => 'responsive',
            ),
          ),
        ),
      ),
      'twitchClip' => 
      array (
        'ssl' => true,
        'urls' => 
        array (
          0 => '~^https?://clips.twitch\\.tv/([a-zA-Z0-9-_]+)$~imu',
          1 => '~^https?://(?:www\\.)?twitch\\.tv/(?:[0-9a-zA-Z-_]+)/clip/([0-9a-zA-Z-_]+)~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'Twitch Clip',
          'provider_url' => '{protocol}://clips.twitch.tv/{1}',
          'html' => 
          array (
            'iframe' => 
            array (
              'width' => 420,
              'height' => 237,
              'src' => '{protocol}://clips.twitch.tv/embed?clip={1}&autoplay=false&tt_medium=clips_embed&parent=www.example.com',
              'scrolling' => 'no',
              'allowfullscreen' => true,
              'frameborder' => 0,
              'sandbox' => 'allow-scripts allow-popups allow-same-origin allow-presentation',
              'layout' => 'responsive',
            ),
          ),
        ),
      ),
      'html5video' => 
      array (
        'ssl' => false,
        'urls' => 
        array (
          0 => '~^https?://(.*).(mp4|ogg|webm)$~imu',
        ),
        'data' => 
        array (
          'type' => 'video',
          'provider_name' => 'HTML5 Video',
          'provider_url' => '{protocol}://{1}.{2}',
          'html' => 
          array (
            'video' => 
            array (
              'width' => 600,
              'height' => 339,
              'source' => 
              array (
                0 => 
                array (
                  'src' => '{protocol}://{1}.webm',
                  'type' => 'video/webm',
                ),
                1 => 
                array (
                  'src' => '{protocol}://{1}.ogg',
                  'type' => 'video/ogg',
                ),
                2 => 
                array (
                  'src' => '{protocol}://{1}.mp4',
                  'type' => 'video/mp4',
                ),
              ),
            ),
          ),
        ),
      ),
    ),
  ),
  'tinker' => 
  array (
    'commands' => 
    array (
    ),
    'alias' => 
    array (
    ),
    'dont_alias' => 
    array (
      0 => 'App\\Nova',
    ),
  ),
);
