<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Contact;
use Illuminate\Http\Request;

class ContactUsController extends Controller
{
    //
    public function index(){

        $contacts=Contact::all();
        
        return view('contact.index',compact('contacts'));
    }
}
