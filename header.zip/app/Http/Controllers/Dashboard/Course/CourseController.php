<?php

namespace App\Http\Controllers\Dashboard\Course;

use App\Http\Controllers\Controller;
use App\Models\Course;
use App\Models\CourseCategory;
use GuzzleHttp\RetryMiddleware;
use Illuminate\Support\Str;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

use Illuminate\Support\Facades\Storage;
use RealRashid\SweetAlert\Facades\Alert;

class CourseController extends Controller
{
    //


    public function index(){

        $allcourses=Course::all();
        return view('course.index',compact('allcourses'));
    }

    public function create(){
        $category=CourseCategory::all();
        return view('course.create',compact('category'));
    }

    public function store(Request $request){

        $request->validate([

          'category_id'=>'required',
          'title'=>'required',
          'image'=>'required|image',
          'summernote'=>'required',
          'youtube_link'=>'required',
          'type'=>'required',
          'price'=>'required',

        ]);

        $orderCode = $this->generateOrderCode();

        $course= new Course();
        $course->title=$request->input('title');
        $course->course_code=$orderCode;
        $course->category_id=$request->input('category_id');
        $course->description=$request->input('summernote');
        $course->youtube_link=$request->input('youtube_link');
        $course->type=$request->input('type');

        if ($request->hasFile('pdf')) {
            $fileNameWithExt = $request->file('pdf')->getClientOriginalName();
            $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('pdf')->getClientOriginalExtension();
            $fileNameToStore = $fileName . '_' . time() . '.' . $extension;

            $path = $request->file('pdf')->storeAs('public/course/', $fileNameToStore);
            $course->pdf_file = $fileNameToStore;
        }

        if ($request->hasFile('image')) {
            $fileNameWithExt = $request->file('image')->getClientOriginalName();
            $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $fileName . '_' . time() . '.' . $extension;

            $path = $request->file('image')->storeAs('public/course/', $fileNameToStore);
            $course->image = $fileNameToStore;
        }

        $course->price=$request->input('price');
        $course->save();

        Alert::toast('Course has been added','success');
       return redirect()->route('all-courses');
    }

    public function edit($id){
        $course=Course::findOrFail($id);
        $category=CourseCategory::all();

        if($course){
            return view('course.edit',compact('course','category'));
        }
    }
    public function update(Request $request){
        // $request->validate([
        // //   'category_id'=>'required',
        // //   'title'=>'required',
        // //   'image'=>'required|image',
        // //   'description'=>'required',
        // //   'youtube_link'=>'required',
        // //   'type'=>'required',
        // //   'price'=>'rquired',
        // ]);


        $course=  Course::findOrFail($request->input('id'));
        $course->title=$request->input('title');
        $course->category_id=$request->input('category_id');
        $course->description=$request->input('summernote');
        $course->youtube_link=$request->input('youtube_link');
        $course->type=$request->input('type');

        if ($request->hasFile('pdf')) {
            Storage::delete('public/course/'.$course->pdf_file);
            $fileNameWithExt = $request->file('pdf')->getClientOriginalName();
            $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('pdf')->getClientOriginalExtension();
            $fileNameToStore = $fileName . '_' . time() . '.' . $extension;

            $path = $request->file('pdf')->storeAs('public/course/', $fileNameToStore);
            $course->pdf_file = $fileNameToStore;
        }

        if ($request->hasFile('image')) {
            Storage::delete('public/course/' . $course->image);

            $fileNameWithExt = $request->file('image')->getClientOriginalName();
            $fileName = pathinfo($fileNameWithExt, PATHINFO_FILENAME);
            $extension = $request->file('image')->getClientOriginalExtension();
            $fileNameToStore = $fileName . '_' . time() . '.' . $extension;

            $path = $request->file('image')->storeAs('public/course/', $fileNameToStore);
            $course->image = $fileNameToStore;
        }

        $course->price=$request->input('price');
        $course->update();

        Alert::toast('Course has been updated','success');
       return redirect()->route('all-courses');
    }

    public function delete($id){

        $course=Course::find($id);

        if($course){
            Storage::delete('public/course/' . $course->image);
            Storage::delete('public/course/'.$course->pdf_file);
            $course->delete();

            Alert::toast('Successfully deleted the course.','success');
            return redirect()->back();
        }else{
            Alert::toast('Something is wroing','error');
            return redirect()->back();
        }
    }

    public function active($id)
    {
        try {
            $course = Course::find($id);
            $course->status = 1;
            $course->save();

            Alert::toast('course has been activated!', 'success');
            return redirect()->route('all-courses');
        } catch (\Exception $e) {
            // Handle exceptions or errors
            Alert::toast('something is wrong!!', 'error');
            return redirect()->back();
        }
    }

    public function inactive($id)
    {
        try {
            $course = Course::find($id);
            $course->status = 0;
            $course->save();

            Alert::toast('course has been inactivated successfully!', 'error');
            return redirect()->route('all-courses');
        } catch (\Exception $e) {
            // Handle exceptions or errors
            Alert::toast('something is wrong!!', 'error');
            return redirect()->back();
        }
    }


    private function generateOrderCode()
    {
        // Generate a random 10-digit number
        $randomNumber = Str::random(10);

        // Check if the code already exists, if so, regenerate
        while (Course::where('course_code', $randomNumber)->exists()) {
            $randomNumber = Str::random(10);
        }

        return $randomNumber;
    }
}

