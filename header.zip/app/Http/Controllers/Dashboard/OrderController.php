<?php

namespace App\Http\Controllers\Dashboard;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\Request;
use RealRashid\SweetAlert\Facades\Alert;

class OrderController extends Controller
{
    //
    public function index(){
        $all_order=Order::with('user','course')->get();
        // dd($all_order);
       return view('order.course_order.index',compact('all_order'));
    }


    public function delete($id)
    {
        try {

            $Order = Order::find($id);
            $Order->delete();
            Alert::toast('Order has been deleted successfully!', 'error');
            return redirect()->route('all-orders');
        } catch (\Exception $e) {
            // Handle exceptions or errors
            Alert::toast('something is wrong!!', 'error');
            return redirect()->back();
        }
    }

    
    public function update_payment(Request $request){

        $order=Order::find($request->input('id'));
        // dd($order->status);

        if($order->status=="paid"){
            // dd($order->status);
            $order->status="pending";
            $order->update();

            Alert::toast('your order payment status changed to pending','info');
            return  redirect()->route('all-orders');
        }
        if($order->status=="pending"){
            // dd($order->status);
            $order->status="paid";
            $order->update();
            Alert::toast('Your order payment status changed to paid','success');
            return  redirect()->route('all-orders');
        }
    }


}
