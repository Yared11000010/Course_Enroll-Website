<!DOCTYPE html>
<html>
<head>
    <title>Reset Password</title>
</head>
<body>
    <h1>Forget Password Email</h1>
    You can reset password from bellow link:
    <a href="{{ route('user-resetpasswordGet', $token) }}">Reset Password</a>
    <br>
    If you did not request a password reset, please ignore this email. Your account remains secure, and no changes have been made.
    <br>
    Best regards,<br>
    xxx company<br>
    Address : xxx <br>
    Email :xxx <br>
    Phone :xxx <br>
</body>
</html>
