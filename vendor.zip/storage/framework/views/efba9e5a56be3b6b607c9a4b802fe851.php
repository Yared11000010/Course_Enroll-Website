<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 200%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/c984329df3ec12300819e4b1e1249dcc.blade.php ENDPATH**/ ?>