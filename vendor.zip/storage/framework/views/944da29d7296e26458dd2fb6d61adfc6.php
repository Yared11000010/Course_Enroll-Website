<?php $__env->startSection('content'); ?>
<div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
    <div class="modal-dialog" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Verify Course Payment</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <form action="<?php echo e(route('check-book-order-transactions')); ?>" method="POST" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>
                <div class="modal-body">
                    <input type="hidden" name="book_id" id="book_id">
                    <div class="form-group">
                        <label for="">Enter Payment Reference Number</label>
                        <input type="text" class="form-control" name="reference" id="" placeholder="Enter reference number">
                    </div>
                    <div class="form-group">
                        <label for="image">Attach Payment Receipt</label>
                        <input type="file" class="form-control" name="image" id="">
                    </div>
                </div>
                <div class="modal-footer">
                    <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
                    <button type="submit" class="btn btn-primary">Check</button>
                </div>
            </form>
        </div>
    </div>
</div>


<div class="shop-area gray-bg pt-100 pb-70">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $enrolled_pdfs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-4">
                <div class="shop-inner mb-30 white-bg">
                    <div class="shop-thumb">
                        <a href="<?php echo e(url('shop-details/'.$book->id)); ?>">
                            <img src="<?php echo e(asset('/storage/book/'.$book->image)); ?>" style="max-height: 300px;" alt="book image">
                        </a>
                    </div>
                    <div class="book-inner-content">
                        <div class="sohop-heading mb-20">
                            <h1 class="shop-book-name"><a href="<?php echo e(url('shop-details/'.$book->id)); ?>"><?php echo e($book->title); ?></a></h1>
                            <p>  <?php
                                $words = str_word_count(strip_tags($book->description), 2);
                                $first20Words = implode(' ', array_slice($words, 0, 10));
                                echo $first20Words . (count($words) > 10 ? '...' : '');
                            ?></p>
                        </div>
                        <div class="shop-inner-details d-flex">
                            <div class="book-price">
                                <span class="price">Price</span>
                                <span class="user-number">$ <?php echo e($book->price); ?></span>
                            </div>
                            <div class="book-price text-right">
                                <?php
                                $order = App\Models\PdfOrder::where('user_id', Auth::user()->id)
                                        ->where('pdf_id', $book->id)
                                        ->first();
                                 ?>
                                <?php if($order && $order->status !== "paid"): ?>
                                    <div class="courses-button f-left">
                                        <button type="button" class="py-2 px-2" style="background-color:#FDC800; border:none;color:black; border-radius:0.3rem;" data-toggle="modal" data-target="#exampleModal" onclick="setCourseId(<?php echo e($book->id); ?>)">
                                            Verify your payment
                                        </button>
                                    </div>
                                <?php endif; ?>
                                <?php if($order && $order->status === "paid"): ?>
                                    <div class="courses-button f-right">
                                        <a href="<?php echo e(url('my-pdf/'.$book->order_code)); ?>" type="button" class="px-2" style="padding:13px 0px; background-color:#FDC800; border:none;color:black; border-radius:0.3rem;">
                                            View Details
                                        </a>
                                    </div>
                                <?php endif; ?>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </div>
</div>
</div>

<script>
    function setCourseId(courseId) {
        document.getElementById("book_id").value = courseId;
    }
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/pages/store/mylearn/index.blade.php ENDPATH**/ ?>