<?php $__env->startSection('content'); ?>
<div class="container mx-auto py-8">
    <h3 class="text-3xl mb-4">Application Details</h3>
    <div class="row shadow p-4 rounded">
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Full Name:</label>
            <p><?php echo e($application->first_name); ?> <?php echo e($application->middle_name); ?> <?php echo e($application->last_name); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Mother's Name:</label>
            <p><?php echo e($application->mother_name); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Birth Date:</label>
            <p><?php echo e($application->birth_date); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Marriage Status:</label>
            <p><?php echo e(ucfirst($application->marriage_status)); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Education Status:</label>
            <p><?php echo e($application->education_status); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Asset Ownership:</label>
            <p><?php echo e($application->asset_ownership); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Application Type:</label>
            <p><?php echo e(ucfirst($application->application_type)); ?></p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Status:</label>
            <p>
                <?php if( $application->status=='1'): ?>
                <span class="badge text-bg-success">Active</span>
                <?php else: ?>
                <span class="badge text-bg-danger">Inactive</span>
                <?php endif; ?>
            </p>
        </div>
        <div class="col-sm-6 mb-3">
            <label class="fw-bold">Passport:</label>
            <p><?php echo e($application->passport); ?></p>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/application-detail.blade.php ENDPATH**/ ?>