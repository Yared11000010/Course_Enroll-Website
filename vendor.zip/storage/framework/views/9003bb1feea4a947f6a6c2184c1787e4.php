<?php $__env->startSection('content'); ?>
<div class="content-wrapper p-4" style="min-height: 1302.4px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>User Attribute</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">User Attribute</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
<div class="row">
    <div class="col-10">
        <div class="card card">
            <div class="card-header">
              <a href="<?php echo e(url('all-user-attributes')); ?>" class="btn btn-secondary">All User Attribute</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <form method="POST" action="<?php echo e(url('store-user-attribute')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                 <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                        <label for="name" class="form-label">User</label>
                        <select class="form-control" name="user_id" id="">
                            <option disabled value="" selected>Select User</option>
                            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                             <option value="<?php echo e($user->id); ?>"><?php echo e($user->name); ?></option>
                             <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                          </select>
                    </div>
                  </div>
                  <div class="col-sm-6">
                    <div class="form-group">
                        <label for="attribute_name" class="form-label">Attribute name</label>
                        <input type="text" class="form-control" id="attribute_name" name="attribute_name"
                             >
                            <?php $__errorArgs = ['attribute_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label for="" class="text-danger"><?php echo e($message); ?></label>
                           <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
                <div class="row">
                  <div class="col-sm-6">
                    <div class="form-group">
                        <label for="attribute_type" class="form-label">Attribute Type</label>
                        <select class="form-control" name="attribute_type" id="">
                            <option >Select Step</option>
                            <option value="text">text</option>
                            <option value="file">file</option>
                            <option value="number">number</option>
                          </select>
                        <?php $__errorArgs = ['attribute_type'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <label for="" class="text-danger"><?php echo e($message); ?></label>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                  </div>
                </div>
                  <div class="row">
                    <div class="col-sm-6">
                        <div class="form-group">
                            <label for="colomun_name" class="form-label"> Column Name</label>
                            <input type="text" class="form-control" id="colomun_name" name="colomun_name">
                                <?php $__errorArgs = ['colomun_name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <label for="" class="text-danger"><?php echo e($message); ?></label>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                      </div>
                  </div>
                  <div class="col-sm-2">
                    <!-- textarea -->
                    <div class="form-group">
                      <button type="submit" class="btn btn-primary w-100">Save</button>
                    </div>
                  </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
        </div>
    <div class="col-2">
    </div>
</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/user_info/add.blade.php ENDPATH**/ ?>