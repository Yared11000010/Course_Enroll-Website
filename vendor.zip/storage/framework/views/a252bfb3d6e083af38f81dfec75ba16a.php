<?php $__env->startSection('content'); ?>
<div class="course-details-area gray-bg pt-100">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8">
                <div class="single-course-details-area mb-30">
                    <div class="course-details-thumb">
                        <img src="img/courses/course_details_thumb.jpg" alt="">
                    </div>
                    <div class="single-course-details white-bg">
                        <div class="course-details-title mb-20">
                            <h1><?php echo e($cor->title); ?></h1>
                        </div>
                        <div class="course-details-tabs">
                            <div class="tab-content" id="pills-tabContent">
                                <div class="tab-pane fade show active" id="pills-home" role="tabpanel" aria-labelledby="pills-home-tab">
                                    <div class="course-details-overview-top">
                                        <p class="course-details-overview-para"></p>
                                        <p><?php echo e($cor->description); ?></p>
                                    </div>
                                    <div class="course-details-overview-bottom d-flex justify-content-between mt-25">
                                        <div class="course-overview-info-left">
                                            <div class="course-overview-student-lecture mt-10">
                                                <span class="gray-color">Download course pdf :
                                                <a href="<?php echo e(url('download-file/'.$cor->pdf_file)); ?>"><?php echo e($cor->pdf_file); ?></a>
                                                </span>
                                                <span class="gray-color">Course Video :
                                                    <?php if (isset($component)) { $__componentOriginal834623cbaf38e68742bc69ac313d1927 = $component; } ?>
<?php $component = BenSampo\Embed\ViewComponents\EmbedViewComponent::resolve(['url' => ''.e($cor->youtube_link).'','aspectRatio' => '22:22'] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('embed'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BenSampo\Embed\ViewComponents\EmbedViewComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
<?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal834623cbaf38e68742bc69ac313d1927)): ?>
<?php $component = $__componentOriginal834623cbaf38e68742bc69ac313d1927; ?>
<?php unset($__componentOriginal834623cbaf38e68742bc69ac313d1927); ?>
<?php endif; ?>
                                                </span>
                                               <div class="container">
                                            </div>
                                            </div>
                                            <div class="course-overview-info-advisor mt-10">
                                                <span class="gray-color">Date : <span class="primary-color"> <?php echo e($cor->created_at); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/pages/course/free_course/details.blade.php ENDPATH**/ ?>