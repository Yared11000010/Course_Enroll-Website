<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 1302.4px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>orders</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">orders</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <a href="javascript:void();" class=" btn btn-outline-dark text-white">
                                     All orders
                                </a>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6"></div>
                                    <div class="col-sm-12 col-md-6"></div>
                                </div>
                                <div class="row">
                                    <div class="col-sm-12">
                                        <table id="example2" class="table table-bordered table-hover dataTable dtr-inline" role="grid" aria-describedby="example2_info">
                                            <thead>
                                                <tr role="row">
                                                    <th class="sorting">ID</th>
                                                    <th class="sorting">User</th>
                                                    <th class="sorting">Course</th>
                                                    <th class="sorting">Payment Reference</th>
                                                    <th class="sorting">Amount</th>
                                                    <th class="sorting">check payment receipt</th>
                                                    <th class="sorting">Status</th>
                                                    <th class="sorting">Date</th>
                                                    <th class="sorting">Action</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $all_order; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $order): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr class="odd">
                                                    <td class="sorting_1 dtr-control" tabindex="0" style=""><?php echo e($order->id); ?></td>
                                                    <td style="" class=""><?php echo e($order->user->first_name ." ".$order->user->last_name); ?></td>
                                                    <td><?php echo e($order->course->title); ?></td>
                                                    <td><?php echo e($order->payment_reference); ?></td>
                                                    <td><?php echo e($order->amount); ?></td>
                                                    <td> <a href="<?php echo e(url('download-payment-receipt/'.$order->payment_receipt)); ?>" target="_blank"><u><?php echo e($order->payment_receipt); ?></u></a>
                                                    </td>
                                                    <td>
                                                       <!-- Button trigger modal -->
                                                    <button type="button" class="btn btn-primary" data-toggle="modal" data-target="#exampleModal">
                                                        <?php echo e($order->status); ?>

                                                    </button>

                                                    <!-- Modal -->
                                                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                                                        <div class="modal-dialog" role="document">
                                                        <div class="modal-content">
                                                            <div class="modal-header">
                                                            <h5 class="modal-title" id="exampleModalLabel"><h1>Are sure to change order payment stastus ?</h1></h5>
                                                            <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                                                <span aria-hidden="true">&times;</span>
                                                            </button>
                                                            </div>
                                                            <form action="<?php echo e(route('update_payment')); ?>" method="POST">
                                                                <?php echo csrf_field(); ?>
                                                                <?php echo method_field('PUT'); ?>
                                                             <input type="hidden" value="<?php echo e($order->id); ?>" name="id">
                                                            <div class="modal-footer">
                                                            <button type="button" class="btn btn-" style="background-color: red;color:white;" data-dismiss="modal">Close</button>
                                                            <button type="submit" class="btn btn-primary">Update Payment Status</button>
                                                            </div>
                                                        </form>
                                                        </div>
                                                        </div>
                                                    </div>
                                                    </td>

                                                    <td>
                                                        <?php echo e($order->created_at); ?>

                                                    </td>
                                                    <td class="" style="">

                                                        <a href="<?php echo e(url('admin/orders/delete/'.$order->id)); ?>"  data-confirm-delete="true" class=" btn-sm">
                                                            <i class="fas fa-trash text-danger"></i>
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>

                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/order/index.blade.php ENDPATH**/ ?>