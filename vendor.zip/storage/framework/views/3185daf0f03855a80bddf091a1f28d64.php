<?php $__env->startSection('content'); ?>

<section id="hero">
    <div class="container">
      <div class="row">
        <div class="col-lg-6  order-2 order-lg-1 d-flex flex-column justify-content-center" data-aos="fade-up">
          <div>
            <h3>Buy Borsa for 100.00 ETB</h3>
        <form method="POST" action="<?php echo e(route('pay')); ?>" id="paymentForm">
            <?php echo e(csrf_field()); ?> 
            <input type="submit" value="Buy" />
        </form>

            <h1>AWAKEN TO A DIFFERENT WORLD EVERY DAY</h1>
            <h2>Are you planning to travel abroad for visiting, studying, or any other occasion ?</h2>
            <p>Don't let the hassle of obtaining a travel visa stress you out.
            Rely on our travel agency la take core of all your visa needs.
            We will guide you through the process and ensure that you have all the necessary documents to obtain your visa.</p>
            <a href="<?php echo e(url('apply')); ?>" class="btn-get-started  ">Apply Now </a>
          </div>
        </div>
        <div class="col-lg-6 order-1 order-lg-2" data-aos="fade-left">
          <img src="<?php echo e(asset('imgs/hero-bg.png')); ?>" class="img-fluid" alt="">
        </div>
      </div>
    </div>
  </section><!-- End Hero -->
  <main id="main">
    <!-- ======= Services Section ======= -->
    <section id="services" class="services section-bg">
      <div class="container">
        <div class="section-title" data-aos="fade-up">
          <h2>OUR SERVICES</h2>
        </div>
        <div class="row">
          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in">
            <div class="icon-box icon-box-user ">
              <div class="icon"><i class="bx bxl-dribbble"></i></div>
              <p class="description">Granting mandatory documents needed for your travel abroad.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="100">
            <div class="icon-box icon-box-lock">
              <div class="icon"><i class="bx bx-file"></i></div>
              <p class="description">Consulting on your application for visa to study, visit, and other occasions at your need.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="200">
            <div class="icon-box icon-box-bag">
              <div class="icon"><i class="bx bx-tachometer"></i></div>
              <p class="description">Preparing Our Clients for Embassy Interviews.</p>
            </div>
          </div>

          <div class="col-md-6 col-lg-3 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="300">
            <div class="icon-box icon-box-blue">
              <div class="icon"><i class="bx bx-file"></i></div>
              <p class="description">Advising on Document and embassy Requirements for your desired country and case.</p>
            </div>
          </div>

        </div>

      </div>
    </section><!-- End Services Section -->

    <section id="services" class="services section-bg">
        <div class="container">
          <div class="section-title" data-aos="fade-up">
            <h2>OUR SERVICES</h2>
          </div>
          <div class="row">
            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in">
              <div class="icon-box icon-box-user ">
                <div class="icon"><i class="bx bxl-dribbble"></i></div>
                <h4 class="title text-center"><a href="">Reliable</a></h4>
                 <p class="description">
                    When it comes to your travel visa needs, reliability is paramount.
                     You need a consulting company that can provide accurate information,
                     expert guidance, and seamless application process. Here's why our travel visa consulting company is the right choice for you.
                </p>
              </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="100">
              <div class="icon-box icon-box-lock">
                <div class="icon"><i class="bx bx-file"></i></div>
                <h4 class="title text-center"><a href="">Successful</a></h4>
                <p class="description">
                  In your travel visa process success is not just a goal; it's a necessity.
                  Choose our travel visa consulting company for seamless and efficient application process that delivers results.
                   This is why we are the right choice for your visa success
                </p>
            </div>
            </div>

            <div class="col-md-6 col-lg-4 d-flex align-items-stretch mb-5 mb-lg-0" data-aos="zoom-in" data-aos-delay="200">
              <div class="icon-box icon-box-bag">
                <div class="icon"><i class="bx bx-tachometer"></i></div>
                <h4 class="title text-center"><a href="">Timely </a></h4>
                <p class="description">
                  we understand the importance of a quick and hassle-free visa application process.
                   Our consultants provide timely reminders, step-by-step assistance,
                   and efficient document preparation to ensure a smooth experience.
                </p>
            </div>
            </div>

          </div>

        </div>
      </section><!-- End Services Section -->

    <!-- ======= Testimonials Section ======= -->

    <!-- ======= Contact Section ======= -->
    <section id="contact" class="contact section-bg">

    </section><!-- End Contact Section -->

  </main><!-- End #main -->

  <!-- ======= Footer ======= -->
  <footer id="footer">
    <div class="footer-top">
      <div class="container">
        <div class="row">

          <div class="col-lg-4 col-md-6">
            <div class="footer-info">
              <h3>GUZUPLUS</h3>
              <p>
                Addis Ababa Gerji Alfoz plaza
                <br>
               , Ethiopia<br><br>
                <strong>Phone:</strong> +1 5589 55488 55<br>
                <strong>Email:</strong> hello@guzoplus.com<br>
              </p>

            </div>
          </div>

          <div class="col-lg-4 col-md-6 footer-links">
            <h4>Useful Links</h4>
            <ul>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Home</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Apply Now</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">My Application</a></li>
              <li><i class="bx bx-chevron-right"></i> <a href="#">Profile</a></li>
            </ul>
          </div>


          <div class="col-lg-4 col-md-6 footer-newsletter right-0">
            <h4>Follow Us</h4>
            <div class="social-links mt-3">
                <a href="#" class="twitter"><i class="bx bxl-twitter"></i></a>
                <a href="#" class="facebook"><i class="bx bxl-facebook"></i></a>
                <a href="#" class="instagram"><i class="bx bxl-instagram"></i></a>
                <a href="#" class="google-plus"><i class="bx bxl-skype"></i></a>
                <a href="#" class="linkedin"><i class="bx bxl-linkedin"></i></a>
              </div>
          </div>
        </div>
      </div>
    </div>
  </footer><!-- End Footer -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/welcome.blade.php ENDPATH**/ ?>