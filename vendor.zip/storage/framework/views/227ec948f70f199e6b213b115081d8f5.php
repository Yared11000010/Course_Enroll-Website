<?php $__env->startSection('content'); ?>
<div class="container">
   
    <div class="row">
    <br>
    <div class="container mx-auto py-8">
        <h1 class="text-3xl">Your Application</h1>

        <div class="row pt-5">
            <?php if(!empty($application)): ?>
            <?php $__currentLoopData = $application; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $application): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="card pt-1" style="width: 18rem; box-shadow: 0px 4px 8px rgba(0, 0, 0, 0.1); border: none;">
                <img src="<?php echo e(asset('/storage/flag/'.$application->country->flag)); ?>" class="card-img-top" alt="...">
                <div class="card-body">
                    <h5 class="card-title"><?php echo e($application->country->name); ?></h5>
                    <p class="card-text">
                        <?php echo e($application->first_name); ?> <?php echo e($application->middle_name); ?> <?php echo e($application->last_name); ?>

                    </p>
                    <p class="card-text">
                        Application Type: <?php echo e($application->application_type); ?>

                    </p>
                    <p class="card-text">
                        Status:
                        <?php if( $application->status=='1'): ?>
                        <span class="badge text-bg-success">Active</span>
                        <?php else: ?>
                        <span class="badge text-bg-danger">Inactive</span>
                        <?php endif; ?>
                    </p>
                    <a href="<?php echo e(url('application-detail/'.$application->id)); ?>" class="btn " style="--bs-btn-padding-y: .25rem; --bs-btn-padding-x: .5rem; --bs-btn-font-size: .75rem; background-color: orange; ">Go to details</a>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php else: ?>

            <h3>You do not have any applications.</h3>

            <?php endif; ?>
        </div>
    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/my_application.blade.php ENDPATH**/ ?>