<?php $__env->startSection('content'); ?>
<style>
    .form { width:485px; margin:0 auto }

</style>
<div id="about" class="about-area pt-100 pb-70">
    <div class="container">
        <div class="row">
            <div class="p-4 form bg-light justify-content-center">
                <h1  class=" justify-content-center text-center" style="color:rgb(0,33,71);">RESET PASSWORD </h1>
                <form id="loginForm" action="<?php echo e(route('user-resetPasswordPost')); ?>" method="POST">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="token" value="<?php echo e($token); ?>">

                    <div class="form-group row">
                        <label for="email_address" class="col-md-4 col-form-label ">Email</label>
                        <div class="col-12">
                            <input type="text" id="email_address" class="form-control" name="email" required autofocus>
                            <?php if($errors->has('email')): ?>
                                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password" class="col-md-4 col-form-label ">Password</label>
                        <div class="col-12">
                            <input type="password" id="password" class="form-control" name="password" id="new_password" required autofocus>
                            <?php if($errors->has('password')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="form-group row">
                        <label for="password-confirm" class="col-md-4 col-form-label">Confirm Password</label>
                        <div class="col-12">
                            <input type="password" id="password-confirm" class="form-control" id="confirm_password" name="password_confirmation" required autofocus>
                            <?php if($errors->has('password_confirmation')): ?>
                                <span class="text-danger"><?php echo e($errors->first('password_confirmation')); ?></span>
                            <?php endif; ?>
                        </div>
                    </div>

                    <div class="col-12">
                        <br>
                        <button type="submit" class="btn btn-primary">
                            Reset Password
                        </button>
                    </div>
                </form>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/forget_password/forget_password_link.blade.php ENDPATH**/ ?>