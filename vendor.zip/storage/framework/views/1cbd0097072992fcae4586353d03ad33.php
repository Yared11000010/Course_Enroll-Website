<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 1302.4px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>column</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">column</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">
                    <div class="card">
                        <div class="card-header">
                            <h3 class="card-title">
                                <a href="<?php echo e(url('create-column')); ?>" class="btn btn-sm text-white">
                                     Add column
                                </a>
                            </h3>
                        </div>
                        <!-- /.card-header -->
                        <div class="card-body">
                            <div id="example2_wrapper" class="dataTables_wrapper dt-bootstrap4">
                                <div class="row">
                                    <div class="col-sm-12 col-md-6"></div>
                                    <div class="col-sm-12 col-md-6"></div>
                                </div>
                                <div class="row">

                                    <div class="col-sm-12">
                                        <?php if(session('success')): ?>
                                            <div class="alert alert-success">
                                                <?php echo e(session('success')); ?>

                                            </div>
                                        <?php endif; ?>
                                        <form action="<?php echo e(route('add.column')); ?>" method="post">
                                            <?php echo csrf_field(); ?>
                                            <div class="form-group">
                                                <label for="column_name" class="col-sm-1-12 col-form-label">New Column Name:</label>
                                                <div class="col-sm-1-12">
                                                    <input type="text" class="form-control" name="column_name" id="column_name" placeholder="">
                                                </div>
                                            </div>

                                            <div class="form-group row">
                                                <div class="">
                                                    <button type="submit" class="btn btn-primary">Add Column</button>
                                                </div>
                                            </div>
                                        </form>
                                        <br>
                                        <table id="example2" class="table table-bordered table-hover dataTable dtr-inline" role="grid" aria-describedby="example2_info">
                                            <thead>
                                                <tr role="row">
                                                    <th class="sorting">Column Name</th>
                                                </tr>
                                            </thead>
                                            <tbody>
                                                <?php $__currentLoopData = $existingColumns; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $column): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <?php if($column !=='id' && $column !=='user_id' && $column !=='country_id' && $column !=='created_at' && $column !=='updated_at'): ?>

                                                <tr class="odd">
                                                     <td style="" class=""><?php echo e($column); ?></td>
                                                    <td class="" style="">
                                                        <a href="" class=" btn-sm">
                                                            <i class="fas fa-edit text-secondary"></i>
                                                        </a>
                                                        <a href="<?php echo e(route('remove.column',['columnName' =>$column])); ?>" class="btn btn-sm btn-danger">
                                                            Remove column
                                                        </a>
                                                    </td>
                                                </tr>
                                                <?php endif; ?>

                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                                            </tbody>

                                        </table>
                                    </div>
                                </div>

                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                </div>
                <!-- /.col -->
            </div>
            <!-- /.row -->
        </div>
        <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/user_extra_info/create.blade.php ENDPATH**/ ?>