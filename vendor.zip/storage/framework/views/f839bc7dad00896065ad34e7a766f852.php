<?php $__env->startSection('content'); ?>
<div class="course-details-area gray-bg pt-100 pb-70">
    <div class="container">
        <div class="row">
            <div class="col-xl-8 col-lg-8">
                <?php $__currentLoopData = $blogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $blog): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <div class="single-blog blog-wrapper blog-list blog-details blue-blog mb-40">
                    <div class="single-blog-main-content mb-30">
                        <div class="blog-thumb mb-35">
                            <a href="<?php echo e(url('blogs/detail/'.$blog->id)); ?>">
                                <img src="<?php echo e(asset('/storage/blog/'.$blog->image)); ?>" alt=""></a>
                        </div>
                        <div class="blog-content news-content">
                            <div class="blog-meta news-meta">
                                <span><?php echo e($blog->created_at); ?></span>
                            </div>
                            <h5><a href="<?php echo e(url('blogs/detail/'.$blog->id)); ?>"><?php echo e($blog->title); ?></a></h5>
                            <p>
                                <?php
                                $words = str_word_count(strip_tags($blog->description), 2);
                                $first20Words = implode(' ', array_slice($words, 0, 200));
                                echo $first20Words . (count($words) > 20 ? '...' : '');
                            ?>
                            </p>
                            <a href="<?php echo e(url('blogs/detail/'.$blog->id)); ?>" class="blog-read-more-btn">Read more</a>
                        </div>
                    </div>
                </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

                <div class="row">
                    <div class="col-xl-12">
                        <nav class="course-pagination mt-10 mb-30" aria-label="Page navigation example">
                           <?php echo e($blogs->links()); ?>

                        </nav>
                    </div>
                </div>
            </div>
            <div class="col-xl-4 col-lg-4">
                <div class="courses-details-sidebar-area">
                    <div class="widget mb-40 white-bg">
                        <div class="sidebar-form">
                            <form action="#">
                                <input placeholder="Search course" type="text">
                                <button type="submit">
                                    <i class="ti-search"></i>
                                </button>
                            </form>
                        </div>
                    </div>
                    <div class="widget mb-40 widget-padding white-bg">
                        <h4 class="widget-title">Category</h4>
                        <div class="widget-link">
                            <ul class="sidebar-link">
                                <?php $__currentLoopData = $blog_category; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $category): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <a href="javascript:void();"><?php echo e($category->name); ?></a>
                                    <span>05</span>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="widget mb-40 widget-padding white-bg">
                        <h4 class="widget-title">Recent Posts</h4>
                        <div class="sidebar-rc-post">
                            <ul>
                                <?php $__currentLoopData = $latestFiveBlogs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $latest): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li>
                                    <div class="sidebar-rc-post-main-area d-flex mb-20">
                                        <div class="rc-post-thumb">
                                            <a href="blog-details.html">
                                                <img src="<?php echo e(asset('/storage/blog/'.$latest->image)); ?>" style="max-width: 40px; max-height:40px; " alt="">
                                            </a>
                                        </div>
                                        <div class="rc-post-content">
                                            <h4>
                                                <a href="blog-details.html"><?php echo e($latest->title); ?></a>
                                            </h4>
                                            <div class="widget-advisors-name">
                                                <span>added by : <span class="f-500"><?php echo e($latest->added_by); ?></span></span>
                                            </div>
                                        </div>
                                    </div>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>


                            </ul>
                        </div>
                    </div>
                    <div class="widget mb-40 widget-padding white-bg">
                        <h4 class="widget-title">Recent Course</h4>
                        <div class="widget-tags clearfix">
                            <ul class="sidebar-tad clearfix">
                                <?php $__currentLoopData = $latestCourse; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $course): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <li >
                                    <a href="#" style="width: 100%"><?php echo e($course->title); ?></a>
                                </li>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </ul>
                        </div>
                    </div>
                    <div class="widget mb-40 widget-padding banner-padding white-bg">
                        <div class="banner-thumb pos-relative">
                            <img src="img/courses/course_banner_01.png" alt="">
                            <div class="bannger-text">
                                <h2 class="text-dark">New eBook are avalible in our shop</h2>
                                <div class="banner-btn">
                                    <a href="<?php echo e(route('shop')); ?>" class="btn white-bg-btn">shop now</a>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/pages/blogs/blogs.blade.php ENDPATH**/ ?>