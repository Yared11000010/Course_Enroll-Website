<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/78iqZBqsSNA"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div>