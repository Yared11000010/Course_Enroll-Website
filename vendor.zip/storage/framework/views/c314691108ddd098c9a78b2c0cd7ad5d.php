<?php $__env->startSection('content'); ?>
<div class="content-wrapper p-4" style="min-height: 1302.4px;">
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Application Attribute</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">Application Attribute</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
    <div class="row">
        <div class="col-6">
            <div class="card card">
                <div class="card-header">
                    <a href="<?php echo e(url('user-application-details/'.$id)); ?>" class="btn btn-secondary">Back to Application Detail</a>
                </div>
                <div class="card-body">
                    <form method="POST" action="<?php echo e(url('store_user_extra_document')); ?>" enctype="multipart/form-data">
                        <?php echo csrf_field(); ?>
                        <div class="row">
                            <div class="col-sm-6">
                                <div class="form-group">
                                    <label for="name" class="form-label">User column:</label>
                                    <input type="hidden" name="user_id" value="<?php echo e($id); ?>">
                                    <select class="form-control" name="coloumn_name" id="">
                                        <option selected disabled value="" >Select</option>
                                        <?php $__currentLoopData = $user_attribute; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($user->id); ?>"><?php echo e($user->coloumn_name); ?></option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                            </div>
                        </div>
                        <div class="row">
                            <div class="col-sm-6">
                             <label for="description">Reason:</label>
                            <textarea name="description" placeholder="Enter Description" class="form-control" id="description" cols="30" rows="10">
                            </textarea>
                          </div>
                        </div>
                        <br>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <button type="submit" class="btn btn-primary w-100">Send to <?php echo e($user->user->name); ?></button>
                            </div>
                        </div>
                    </form>
                </div>
                <!-- /.card-body -->
            </div>
        </div>
        <div class="col-2">

        </div>
    </div>
</div>

<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.layout_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/users_application/detail.blade.php ENDPATH**/ ?>