<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 50%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/12f6f593aeb7b875cfa176b73f89a5e7.blade.php ENDPATH**/ ?>