<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
    <br>
    <div class="container mx-auto py-8">
        <h1 class="text-3xl">Available Countries</h1>
        <p>Travel with us to the country of your choice without any risk</p>
    <div class="row pt-5">
        <?php $__currentLoopData = $countries; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $con): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <div class="col-md-4">
            <div class="card shadow-sm" style="width: 18rem; border: none;">
                <img class="card-img-top" src="<?php echo e(asset('/storage/flag/'.$con->flag)); ?>" alt="Card image cap">
                <div class="card-body d-flex flex-column">
                    <h5 class="card-title"><?php echo e($con->name); ?></h5>
                    <div class="d-flex justify-content-between align-items-center mb-2">
                        <p class="card-text mb-0"><?php echo e($con->description); ?></p>
                        <a href="<?php echo e(url('country/'.$con->id)); ?>" class="btn text-sm-center " style="background-color:orange">Start Application</a>
                    </div>
                </div>
            </div>
        </div>

        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </div>

    </div>
   </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/apply.blade.php ENDPATH**/ ?>