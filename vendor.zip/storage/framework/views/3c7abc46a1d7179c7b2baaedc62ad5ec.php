<?php
use Illuminate\Support\Facades\Session;
?>


<?php $__env->startSection('content'); ?>
    <div class="container">
                  <table class="table table-striped ">
                        <thead class="thead-">
                            <tr>
                                <th>Title</th>
                                <td>Category</td>
                                <th>Image</th>
                                <th>Price</th>
                            </tr>
                            </thead>
                            <tbody>
                                <tr>
                                    <td><?php echo e($course->title); ?></td>
                                    <td><?php echo e($course->category->name); ?></td>
                                    <td>
                                        <img src="<?php echo e(asset('/storage/course/'.$course->image)); ?>" style="max-height: 40px; max-width:40px;"  alt="">
                                    </td>
                                    <td>
                                        <?php echo e($course->price); ?>

                                    </td>
                                </tr>
                            </tbody>
                    </table>
                    <?php
                          Session::put('amount', $course->price);
                          Session::put('course',$course->id);
                    ?>
                    <div class=" justify-content-end">
                        <form method="POST" action="<?php echo e(route('pay')); ?>" id="paymentForm">
                            <?php echo csrf_field(); ?>
                        <input type="hidden" name="course_amount" value="<?php echo e($course->price); ?>">
                         <input type="submit" class="btn btn-primary" value="Checkout Course" />
                        </form>
                    </div>
    </div>
    <br>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/Frontend/pages/course/enroll/index.blade.php ENDPATH**/ ?>