<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/950c58cf41d4e9bc6992f417f6b2a836.blade.php ENDPATH**/ ?>