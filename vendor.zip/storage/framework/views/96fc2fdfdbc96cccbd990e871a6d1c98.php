<?php $__env->startSection('content'); ?>

<div class="content-wrapper p-4" style="min-height: 1302.4px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>Book</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">Book</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>
<div class="row">
    <div class="col-8">
        <div class="card card">
            <div class="card-header">
              <a href="<?php echo e(route('student-says')); ?>" class="btn btn-secondary">All Student Comments</a>
            </div>
            <!-- /.card-header -->
            <div class="card-body">
                <form method="POST" action="<?php echo e(route('update-student-say')); ?>" enctype="multipart/form-data">
                    <?php echo csrf_field(); ?>
                    <?php echo method_field('PUT'); ?>
                 <div class="row">
                  <div class="col-sm-10">
                    <!-- text input -->
                    <input type="hidden" name="id" value="<?php echo e($testmony->id); ?>">
                    <div class="form-group">
                        <label for="name" class="form-label">Name</label>
                        <input type="text" class="form-control" id="name" value="<?php echo e($testmony->name); ?>" name="name"
                            required autocomplete="name" autofocus>
                    </div>
                  </div>

                </div>
                <div class="row">
                    <div class="col-sm-10">
                      <div class="form-group">
                          <textarea class="form-control" name="comment" id="summernote">
                            <?php echo e($testmony->comment); ?>

                          </textarea>
                      </div>
                    </div>
                  </div>
                  <div class="row">
                      <div class="col-sm-10">
                         <div class="form-group">
                           <label for="Jobs">Jobs</label>
                           <input type="text" class="form-control" value="<?php echo e($testmony->job); ?>" name="job" id="" placeholder="Enter Jobs">
                         </div>
                      </div>
                    </div>

                  <div class="row">
                    <div class="col-sm-2">
                        <!-- textarea -->
                        <div class="form-group">
                          <button type="submit" class="btn btn w-100 text-white">Save</button>
                        </div>
                      </div>
                  </div>
              </form>
            </div>
            <!-- /.card-body -->
          </div>
        </div>

</div>
</div>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('dashboard.layout_dashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/testmony/edit.blade.php ENDPATH**/ ?>