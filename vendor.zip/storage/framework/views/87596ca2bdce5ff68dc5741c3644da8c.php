<footer class="main-footer">
    <strong>Copyright © 2024 </strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">
      
    </div>
  </footer>
<?php /**PATH C:\Users\yared\Videos\travel\resources\views/dashboard/footer.blade.php ENDPATH**/ ?>