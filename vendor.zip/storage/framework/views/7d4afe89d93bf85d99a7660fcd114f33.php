<?php $__env->startSection('content'); ?>
<style>
    .circle {
        border-radius: 50%;
        width: 50px;
        height: 50px;
        display: flex;
        align-items: center;
        justify-content: center;
    }

</style>
<div class="container">
    <h2 class="text-lg ">All information and description</h2>
    <?php $__currentLoopData = $requriements; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $req): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <div class="row flex-md-column mt-2">
        <div class="col-12 col-md-1 text-center mb-2">
            <div class="border circle">
                <?php echo e($req->step->number); ?>

            </div>
        </div>
    </div>
    <div class="d-flex" style="margin-left:20px;">
        <div style="width: 5px; background-color: chocolate; margin-right: 10px; border-radius:0.2rem;" class="ml-2"></div>
        <div class="flex-grow-1">
            <div class="gx-3">
                <div class="border rounded pl-3">
                    <div class="p-3 h4 font-weight-bold">
                        <b><?php echo e($req->step->name); ?></b>
                    </div>
                    <?php if($req->step->description): ?>
                    <div class="p-2">
                        <label for="">Description: <?php echo e($req->step->description); ?></label>
                    </div>
                    <?php endif; ?>
                    <?php if($req->price): ?>
                    <div class="p-2">
                        <label for="">Price: <?php echo e($req->price); ?> Birr</label>
                    </div>
                    <?php endif; ?>
                    <?php if($req->period): ?>
                    <div class="p-2">
                        <label for="">Period: <?php echo e($req->period); ?></label>
                    </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<div class="d-flex justify-content-center mt-2">
    <a class="btn p-2"  href="<?php echo e(url('countires/'.$id)); ?>"  style="background-color:rgb(253,126,20);color:white;">Start Application</a>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/detail_info.blade.php ENDPATH**/ ?>