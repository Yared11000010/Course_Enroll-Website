<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 75%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/b5a4d813140681871a8b4f3b61c36356.blade.php ENDPATH**/ ?>