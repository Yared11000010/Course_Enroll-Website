<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-body pt-3">
                 <form action="<?php echo e(url('store_user_extra_doc')); ?>" method="POST" enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                      <input type="hidden" name="user_id" value="">

                    <div class="container">
                        <div class="form-group">
                            <label for="text-title">Reason &nbsp;<?php echo e($extra_doc->description); ?></label>
                            <p>
                            Send <b><?php echo e($user_attribute->attribute_name); ?></b>
                            </p>
                        </div>
                        <?php if($user_attribute): ?>
                            <div class="form-group">
                                <label for="<?php echo e($user_attribute->attribute_coloumn_name); ?>"><?php echo e($user_attribute->attribute_name); ?></label>
                                <input type="<?php echo e($user_attribute->attribute_type); ?>" class="form-control" name="<?php echo e($user_attribute->attribute_coloumn_name); ?>" id="<?php echo e($user_attribute->filter_column); ?>">
                            </div>
                        <?php endif; ?>
                        <br><br>
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-primary">Send to admin</button>
                        </div>
                    </div>
                  <br>
                 </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/send_extra_doc.blade.php ENDPATH**/ ?>