f

<?php $__env->startSection('content'); ?>
<style>
    .form { width:485px; margin:0 auto }

</style>
<div id="about" class="about-area pt-100 pb-70">
    <div class="container">
        <div class="row">
            <div class="p-4 form bg-light justify-content-center">
                <h1  class=" justify-content-center text-center" style="color:rgb(0,33,71);">FORGET PASSWORD </h1>
            <form method="POST" action="<?php echo e(route('user-forgetpassword')); ?>">
                    <?php echo csrf_field(); ?>
                <div class="form-group">
                <label for="">Email</label>
                <input type="email" class="form-control" name="email" id="" aria-describedby="emailHelpId" placeholder="Email">
                <?php if($errors->has('email')): ?>
                <span class="text-danger"><?php echo e($errors->first('email')); ?></span>
                <?php endif; ?>
                </div>

                  <button type="submit" class="btn events-form-btn ">Send rest password link</button>
            </form>
        </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/forget_password/forget.blade.php ENDPATH**/ ?>