<?php if (isset($component)) { $__componentOriginal55b4256047def452405a26348ddeec03 = $component; } ?>
<?php $component = BenSampo\Embed\ViewComponents\ResponsiveWrapperViewComponent::resolve(['aspectRatio' => $aspectRatio] + (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag ? (array) $attributes->getIterator() : [])); ?>
<?php $component->withName('embed-responsive-wrapper'); ?>
<?php if ($component->shouldRender()): ?>
<?php $__env->startComponent($component->resolveView(), $component->data()); ?>
<?php if (isset($attributes) && $attributes instanceof Illuminate\View\ComponentAttributeBag && $constructor = (new ReflectionClass(BenSampo\Embed\ViewComponents\ResponsiveWrapperViewComponent::class))->getConstructor()): ?>
<?php $attributes = $attributes->except(collect($constructor->getParameters())->map->getName()->all()); ?>
<?php endif; ?>
<?php $component->withAttributes([]); ?>
    <iframe
        aria-label="foo <?php echo e($label); ?>"
        src="https://www.youtube-nocookie.com/embed/<?php echo e($videoId); ?>"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
 <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php if (isset($__componentOriginal55b4256047def452405a26348ddeec03)): ?>
<?php $component = $__componentOriginal55b4256047def452405a26348ddeec03; ?>
<?php unset($__componentOriginal55b4256047def452405a26348ddeec03); ?>
<?php endif; ?>
<?php /**PATH C:\Users\yared\Videos\travel\resources\views/vendor/embed/services/youtube.blade.php ENDPATH**/ ?>