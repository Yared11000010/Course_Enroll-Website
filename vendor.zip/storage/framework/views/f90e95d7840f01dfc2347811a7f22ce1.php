<?php $__env->startSection('content'); ?>
<div class="shop-area gray-bg pt-100 pb-70">
    <div class="container">
        <div class="row">
            <?php $__currentLoopData = $books; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $book): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="col-xl-3">
                <div class="shop-inner mb-30 white-bg">
                    <div class="shop-thumb">
                        <a href="<?php echo e(url('shop-details/'.$book->id)); ?>">
                            <img src="<?php echo e(asset('/storage/book/'.$book->image)); ?>" style="max-height: 300px;" alt="book image">
                        </a>
                    </div>
                    <div class="book-inner-content">
                        <div class="sohop-heading mb-20">
                            <h1 class="shop-book-name"><a href="<?php echo e(url('shop-details/'.$book->id)); ?>"><?php echo e($book->title); ?></a></h1>
                            <p>  <?php
                                $words = str_word_count(strip_tags($book->description), 2);
                                $first20Words = implode(' ', array_slice($words, 0, 10));
                                echo $first20Words . (count($words) > 10 ? '...' : '');
                            ?></p>
                        </div>
                        <div class="shop-inner-details d-flex">
                            <div class="book-price">
                                <span class="price">Price</span>
                                <span class="user-number">$ <?php echo e($book->price); ?></span>
                            </div>
                            <div class="book-ratings text-right">
                                <ul>
                                    <li><a href="<?php echo e(url('enroll-book/'.$book->order_code)); ?>" class="" style="background-color: #FDC800;color:black;padding:8px 18px;">Enroll</a></li>
                                </ul>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            </div>
</div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('Frontend.layouts.main', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/Frontend/pages/store/store.blade.php ENDPATH**/ ?>