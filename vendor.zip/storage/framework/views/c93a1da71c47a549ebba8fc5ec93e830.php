<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card border-0">
              <div class="card-body">
                <div class="alert alert-success broder-0 shadow-sm" role="alert">
                    <h4 class="alert-heading">Well done!</h4>
                    <p></p>
                    <hr>
                    <p class="mb-0">Your extra information has been sent to the admin successfully</p>
                  </div>
              </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/success.blade.php ENDPATH**/ ?>