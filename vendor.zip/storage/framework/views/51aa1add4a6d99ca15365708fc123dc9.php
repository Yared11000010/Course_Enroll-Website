<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row">
        <div class="col-3">
        </div>
        <div class="col-7 p-4" style="background-color:rgb(238, 247, 255);">
            <form method="POST" action="">
                <?php echo csrf_field(); ?>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="first_name">First Name</label>
                            <input type="text" class="form-control" id="first_name" name="first_name">
                        </div>
                    </div>
                    <div class="col-md-6">

                        <div class="form-group">
                            <label for="middle_name">Middle Name</label>
                            <input type="text" class="form-control" id="middle_name" name="middle_name">
                        </div>
                    </div>
                </div>


                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="last_name">Last Name</label>
                            <input type="text" class="form-control" id="last_name" name="last_name">
                        </div>

                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="education_status">Education Status</label>
                            <input type="text" class="form-control" id="education_status" name="education_status">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="asset_ownership">Asset Ownership</label>
                            <select class="form-control" id="asset_ownership" name="asset_ownership">
                                <option value="0">Car</option>
                                <option value="1">House</option>
                                <option value="2">Both</option>
                                <option value="3">None</option>
                            </select>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="location">Location</label>
                            <input type="text" class="form-control" id="location" name="location">
                        </div>
                    </div>
                </div>

                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="experience">Experience</label>
                            <input type="text" class="form-control" id="experience" name="experience">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="gender">Gender</label>
                            <select class="form-control" id="gender" name="gender">
                                <option value="male">Male</option>
                                <option value="female">Female</option>
                                <option value="other">Other</option>
                            </select>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="age">Age</label>
                            <input type="number" class="form-control" id="age" name="age">
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="family_count">Family Count</label>
                            <input type="number" class="form-control" id="family_count" name="family_count">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="family_members">Family Members</label>
                            <input type="text" class="form-control" id="family_members" name="family_members">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="phone_number">Phone Number</label>
                            <input type="text" class="form-control" id="phone_number" name="phone_number">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="birth_place">Birth Place</label>
                            <input type="text" class="form-control" id="birth_place" name="birth_place">
                        </div>
                    </div>

                    <div class="col-md-6">
                        <div class="form-group">
                            <label for="email">Email</label>
                            <input type="email" class="form-control" id="email" name="email">
                        </div>
                    </div>
                </div>
                <div class="row">
                <div class="col-md-6">
                    <div class="form-group">
                        <label for="application_type">Application Type</label>
                        <select class="form-control" id="application_type" name="application_type">
                            <option value="1">Visit</option>
                            <option value="2">Student</option>
                            <option value="3">Others</option>
                        </select>
                    </div>
                </div>
                </div>

                 <div class="row">
                    <div class="col-md-6">
                   <div class="form-group">
                    <label for="passport_field">Passport Field</label>
                    <input type="file" class="form-control" id="passport_field" name="passport_field">
                </div>
                </div>
                <div class="col-md-6">
                <div class="form-group">
                    <label for="birth_certificate">Birth Certificate</label>
                    <input type="file" class="form-control" id="birth_certificate" name="birth_certificate">
                </div>
                </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                <div class="form-group">
                    <label for="educational_materials">Educational Materials</label>
                    <input type="file" class="form-control" id="educational_materials" name="educational_materials">
                </div>
                </div>
                <div class="col-md-6">
                <br>
                <button type="submit" class="btn btn-primary btn-block w-100">Submit</button>
                </div>
                </div>
            </form>
        </div>
        <div class="col-3">

        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/continue_application.blade.php ENDPATH**/ ?>