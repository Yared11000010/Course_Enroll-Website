<aside class="main-sidebar sidebar-light-orange   elevation-4">
    <!-- Brand Logo -->
    <a href="<?php echo e(url('/')); ?>" class="brand-link text-center">
      <span class="brand-text font-weight-dark text-center">
        <img src="<?php echo e(asset('dashboard/dist/img/logo.png')); ?>" style="height: 60px;" alt="">
      </span>
    </a>

    <!-- Sidebar -->
    <div class="sidebar os-host os-theme-light os-host-overflow os-host-overflow-y os-host-resize-disabled os-host-scrollbar-horizontal-hidden os-host-transition"><div class="os-resize-observer-host observed"><div class="os-resize-observer" style="left: 0px; right: auto;"></div></div><div class="os-size-auto-observer observed" style="height: calc(100% + 1px); float: left;"><div class="os-resize-observer"></div></div><div class="os-content-glue" style="margin: 0px -8px; width: 249px; height: 316px;"></div><div class="os-padding"><div class="os-viewport os-viewport-native-scrollbars-invisible" style="overflow-y: scroll;"><div class="os-content" style="padding: 0px 8px; height: 100%; width: 100%;">
      <!-- Sidebar user panel (optional) -->
      <div class="user-panel mt-3 pb-3 mb-3 d-flex">
        <div class="image">
        </div>
        <div class="info">
          <h2 href="#" class="d-block">Wellcome : <b><?php echo e(Auth::guard('admin')->user()->name); ?></b> </h2>
        </div>
      </div>
      <!-- Sidebar Menu -->
      <nav class="mt-2">
        <ul class="nav nav-pills nav-sidebar flex-column" data-widget="treeview" role="menu" data-accordion="false">
          <!-- Add icons to the links using the .nav-icon class
               with font-awesome or any other icon font library -->
          <li class="nav-item menu-open">
            <a href="<?php echo e(url('admin/dashboard')); ?>" class="nav-link active">
              <i class="nav-icon fas fa-tachometer-alt"></i>
              <p>
                Dashboard
              </p>
            </a>
          </li>
          <li class="nav-item <?php echo e(request()->is('admin/all-admins')?'menu-open':''); ?> <?php echo e(request()->is('admin/create-admin')?'menu-open':''); ?> <?php echo e(request()->is('admin/edit-admin/*')?'menu-open':''); ?>">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/all-admins')? 'active':''); ?> <?php echo e(request()->is('admin/create-admin')?'active':''); ?> <?php echo e(request()->is('admin/edit-admin/*')?'active':''); ?>">
              <i class="nav-icon fas fa-user "></i>
              <p>
                Admins
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
                <li class="nav-item">
                    <a href="<?php echo e(url('admin/all-admins')); ?>" class="nav-link <?php echo e(request()->is('admin/all-admins')? 'active':''); ?> ">
                      <i class="far fa-square  nav-icon"></i>
                      <p> Admins</p>
                    </a>
                  </li>
                <li class="nav-item">
                <a href="<?php echo e(url('admin/create-admin')); ?>" class="nav-link <?php echo e(request()->is('admin/create-admin')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Create Admin</p>
                </a>
              </li>

            </ul>
          </li>

          <li class="nav-item <?php echo e(request()->is('admin/all-users')?'menu-open':''); ?> <?php echo e(request()->is('admin/create-user')?'menu-open':''); ?> <?php echo e(request()->is('admin/edit-user/*')?'menu-open':''); ?>">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/all-users')? 'active':''); ?> <?php echo e(request()->is('admin/create-user')?'active':''); ?> <?php echo e(request()->is('admin/edit-user/*')?'active':''); ?>">
              <i class="nav-icon fas fa-users "></i>
              <p>
                Users
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">

              <li class="nav-item">
                <a href="<?php echo e(url('admin/all-users')); ?>" class="nav-link <?php echo e(request()->is('admin/all-users')? 'active':''); ?> ">
                  <i class="far fa-square  nav-icon"></i>
                  <p>Users</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(url('admin/create-user')); ?>" class="nav-link <?php echo e(request()->is('admin/create-user')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Create User</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item <?php echo e(request()->is('admin/contact-us')?'menu-open':''); ?> ">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/contact-us')? 'active':''); ?>">
                <i class=" fas  fa-database" >
                </i>
                 <p>
                Contact Messages
                <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(url('admin/contact-us')); ?>" class="nav-link <?php echo e(request()->is('admin/contact-us')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Messages</p>
                </a>
              </li>

            </ul>
          </li>


          <li class="nav-item <?php echo e(request()->is('admin/blogs')?'menu-open':''); ?>  <?php echo e(request()->is('admin/blogs/*')?'menu-open':''); ?>  <?php echo e(request()->is('admin/blog-comment*')?'menu-open':''); ?>  <?php echo e(request()->is('admin/blog-categories')?'menu-open':''); ?> <?php echo e(request()->is('admin/blog/category*')?'menu-open':''); ?> ">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/blogs*')?'active':''); ?> <?php echo e(request()->is('admin/blogs')?'active':''); ?>  <?php echo e(request()->is('admin/blog-comment*')?'active':''); ?>  <?php echo e(request()->is('admin/blog-categories')?'active':''); ?>  <?php echo e(request()->is('admin/blog/category*')?'active':''); ?>">
              <i class="nav-icon fas fa-newspaper "></i>
              <p>
                Blogs
                 <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('blogs')); ?>" class="nav-link <?php echo e(request()->is('admin/blogs')?'active':''); ?> <?php echo e(request()->is('admin/blogs*')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Blogs</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('blog-categories')); ?>" class="nav-link <?php echo e(request()->is('admin/blog-categories')?'active':''); ?> <?php echo e(request()->is('admin/blog/category*')?'active':''); ?>  ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Blog Categories</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('blog-comments')); ?>" class="nav-link <?php echo e(request()->is('admin/blog-comment*')?'active':''); ?> <?php echo e(request()->is('admin/blog-comment')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Blog Comments</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item <?php echo e(request()->is('admin/newslettersubscribers')?'menu-open':''); ?>  <?php echo e(request()->is('admin/newslettersubscribers/*')?'menu-open':''); ?>  <?php echo e(request()->is('admin/send-email-to-all')?'menu-open':''); ?>">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/newslettersubscribers*')?'active':''); ?> <?php echo e(request()->is('admin/newslettersubscribers')?'active':''); ?>  <?php echo e(request()->is('admin/send-email-to-all')?'active':''); ?>">
              <i class="nav-icon fas fa-file"></i>
              <p>
                 Subscribers
                 <i class="fas fa-angle-left right"></i>
              </p>
            </a>
            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('newslettersubscribers')); ?>" class="nav-link <?php echo e(request()->is('admin/newslettersubscribers')?'active':''); ?> <?php echo e(request()->is('admin/newslettersubscribers*')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>List of Subscribers</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('send-email-to-all')); ?>" class="nav-link <?php echo e(request()->is('admin/send-email-to-all')?'active':''); ?> <?php echo e(request()->is('admin/send-email-to-all*')?'active':''); ?>  ">
                  <i class="far fa-square nav-icon"></i>
                  <p>Send Email</p>
                </a>
              </li>
            </ul>
          </li>
          <li class="nav-item <?php echo e(request()->is('admin/all-courses')?'menu-open':''); ?>  <?php echo e(request()->is('admin/courses/*')?'menu-open':''); ?>  <?php echo e(request()->is('admin/course/*')?'menu-open':''); ?> <?php echo e(request()->is('admin/course-categories')?'menu-open':''); ?>">
            <a href="#" class="nav-link bg-light <?php echo e(request()->is('admin/all-courses')?'active':''); ?> <?php echo e(request()->is('admin/courses/*')?'active':''); ?> <?php echo e(request()->is('admin/course*')?'active':''); ?> <?php echo e(request()->is('admin/course-categories')?'active':''); ?>">
              <i class="nav-icon fas fa-book"></i>
              <p>
                 Courses
                 <i class="fas fa-angle-left right"></i>
              </p>
            </a>

            <ul class="nav nav-treeview">
              <li class="nav-item">
                <a href="<?php echo e(route('all-courses')); ?>" class="nav-link <?php echo e(request()->is('admin/all-courses')?'active':''); ?>  <?php echo e(request()->is('admin/course/edit*')?'active':''); ?> ">
                  <i class="far fa-square nav-icon"></i>
                  <p>List of Course</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('add-course')); ?>" class="nav-link <?php echo e(request()->is('admin/course/add')?'active':''); ?>">
                  <i class="far fa-square nav-icon"></i>
                  <p>Create Course</p>
                </a>
              </li>
              <li class="nav-item">
                <a href="<?php echo e(route('course-categories')); ?>" class="nav-link <?php echo e(request()->is('admin/course/category*')?'active':''); ?> <?php echo e(request()->is('admin/course-categories')?'active':''); ?>" >
                  <i class="far fa-square nav-icon"></i>
                  <p> Course Categories</p>
                </a>
              </li>
            </ul>
            <li class="nav-item <?php echo e(request()->is('admin/all-orders')?'menu-open':''); ?>">
                <a href="javascript:void();" class="nav-link bg-light <?php echo e(request()->is('admin/all-orders')?'active':''); ?>">
                  <i class="nav-icon fas">
                    <svg id='Purchase_Order_24' width='15' height='15' viewBox='0 0 24 24' xmlns='http://www.w3.org/2000/svg' xmlns:xlink='http://www.w3.org/1999/xlink'><rect width='24' height='24' stroke='none' fill='#000000' opacity='0'/>
                        <g transform="matrix(0.43 0 0 0.43 12 12)" >
                        <path style="stroke: none; stroke-width: 1; stroke-dasharray: none; stroke-linecap: butt; stroke-dashoffset: 0; stroke-linejoin: miter; stroke-miterlimit: 4; fill: rgb(0,0,0); fill-rule: nonzero; opacity: 1;" transform=" translate(-25, -25)" d="M 6 2 L 6 48 L 7 48 L 44 48 L 44 2 L 6 2 z M 8 4 L 42 4 L 42 46 L 8 46 L 8 4 z M 13 11 L 13 13 L 37 13 L 37 11 L 13 11 z M 13 25 L 13 27 L 17 27 L 17 25 L 13 25 z M 20 25 L 20 27 L 37 27 L 37 25 L 20 25 z M 13 31 L 13 33 L 17 33 L 17 31 L 13 31 z M 20 31 L 20 33 L 37 33 L 37 31 L 20 31 z M 13 37 L 13 39 L 17 39 L 17 37 L 13 37 z M 20 37 L 20 39 L 37 39 L 37 37 L 20 37 z" stroke-linecap="round" />
                        </g>
                        </svg>
                  </i>
                  <p>
                     Orders
                     <i class="fas fa-angle-left right"></i>
                  </p>
                </a>
              <ul class="nav nav-treeview">
                <li class="nav-item">
                  <a href="<?php echo e(route('all-orders')); ?>" class="nav-link <?php echo e(request()->is('admin/all-orders')?'active':''); ?>">
                    <i class="far fa-square nav-icon"></i>
                    <p>List of Orders</p>
                  </a>
                </li>
              </ul>
            </li>
          </li>
        </ul>
      </nav>
      <!-- /.sidebar-menu -->
    </div></div></div><div class="os-scrollbar os-scrollbar-horizontal os-scrollbar-unusable os-scrollbar-auto-hidden"><div class="os-scrollbar-track"><div class="os-scrollbar-handle" style="width: 100%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar os-scrollbar-vertical os-scrollbar-auto-hidden"><div class="os-scrollbar-track"><div class="os-scrollbar-handle" style="height: 23.326%; transform: translate(0px, 0px);"></div></div></div><div class="os-scrollbar-corner"></div></div>
    <!-- /.sidebar -->
  </aside>
<?php /**PATH C:\Users\yared\Videos\travel\resources\views/dashboard/sidebar.blade.php ENDPATH**/ ?>