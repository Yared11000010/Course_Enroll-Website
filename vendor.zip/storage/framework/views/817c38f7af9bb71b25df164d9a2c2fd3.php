<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 100%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/7152525d6cf5fe439813dfc25a029e8f.blade.php ENDPATH**/ ?>