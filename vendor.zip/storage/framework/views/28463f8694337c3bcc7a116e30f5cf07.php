<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 150%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/290073493d66f6361c5b9de3d2c0b30a.blade.php ENDPATH**/ ?>