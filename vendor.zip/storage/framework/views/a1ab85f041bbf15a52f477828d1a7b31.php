<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: <?php echo e($aspectRatio->asPercentage()); ?>%"
>
    <?php echo e($slot); ?>

</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\resources\views/vendor/embed/components/responsive-wrapper.blade.php ENDPATH**/ ?>