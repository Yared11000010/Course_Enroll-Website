<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card shadow-sm border-0">
                <div class="card-body pt-3">
                 <form action="<?php echo e(url('store-extra-information')); ?>" method="POST"  enctype="multipart/form-data">
                 <?php echo csrf_field(); ?>
                    <input type="hidden" name="user_id" value="">
                    <div class="container">
                        <div class="form-group">
                            <label for="text-title"><br>
                                Reason &nbsp; <br>
                                <?php echo e($user_extra_document->description); ?>

                            </label>
                        </div>
                        <?php $__currentLoopData = $user_attributes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user_attributes): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        
                            <div class="form-group">
                                <label for="<?php echo e($user_attributes->coloumn_name); ?>"><?php echo e($user_attributes->attribute_name); ?></label>
                                <input type="<?php echo e($user_attributes->attribute_type); ?>" class="form-control" name="<?php echo e($user_attributes->coloumn_name); ?>" >
                            </div>
                        
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <br>
                        <div class="d-flex justify-content-between">
                            <button type="submit" class="btn btn-warning">Submit your information</button>
                        </div>
                    </div>
                  <br>
                 </form>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/create_user_extra_document.blade.php ENDPATH**/ ?>