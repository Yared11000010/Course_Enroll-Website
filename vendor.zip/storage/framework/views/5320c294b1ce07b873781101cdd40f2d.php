<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 56.25%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/mCOOddO4kkY"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/ac5f38ab2e9957cb1cb044595ea8ca65.blade.php ENDPATH**/ ?>