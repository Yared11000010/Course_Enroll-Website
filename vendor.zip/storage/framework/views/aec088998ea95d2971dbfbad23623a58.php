<div 
    class="laravel-embed__responsive-wrapper" 
    style="padding-bottom: 44.44%"
>
    <iframe
        aria-label="foo An embedded video"
        src="https://www.youtube-nocookie.com/embed/g_BvUeWuMiI"
        frameborder="0"
        allow="accelerometer; encrypted-media; gyroscope; picture-in-picture"
        allowfullscreen
    ></iframe>
</div><?php /**PATH C:\Users\yared\Videos\CourseEnroll\storage\framework\views/32b5b34962091ae7a30c6311fd4f8487.blade.php ENDPATH**/ ?>