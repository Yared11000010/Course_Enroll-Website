<?php $__env->startSection('content'); ?>
<div class="content-wrapper" style="min-height: 1302.4px;">
    <!-- Content Header (Page header) -->
    <section class="content-header">
        <div class="container-fluid">
            <div class="row mb-2">
                <div class="col-sm-6">
                    <h1>User Applications</h1>
                </div>
                <div class="col-sm-6">
                    <ol class="breadcrumb float-sm-right">
                        <li class="breadcrumb-item"><a href="javascript:void();">Home</a></li>
                        <li class="breadcrumb-item active">User Applications</li>
                    </ol>
                </div>
            </div>
        </div><!-- /.container-fluid -->
    </section>

    <!-- Main content -->
    <section class="content">
        <div class="container-fluid">
            <div class="row">
                <div class="col-12">

                    <div class="modal fade" id="exampleModal" tabindex="-1" role="dialog" aria-labelledby="exampleModalLabel" aria-hidden="true">
                        <div class="modal-dialog" role="document">
                            <div class="modal-content">
                                <div class="modal-header">
                                    <h5 class="modal-title text-dark">Modal title</h5>
                                    <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                        <span aria-hidden="true">&times;</span>
                                    </button>
                                </div>
                                <div class="modal-body">
                                    
                                </div>
                            </div>
                        </div>
                    </div>

                    <div class="container mt-2">
                        <a href="<?php echo e(url('view-user-attribute/'.$application->user_id)); ?>" class="btn text-white">
                            Send a message to a user to send extra document to verify application
                        </a>

                        <div class="card mb-3 mt-2">

                            <div class="card-body">
                                <h5 class="card-title">User Information</h5>
                                <br>
                                <form>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputUsername">Username</label>
                                            <input type="text" class="form-control" id="inputUsername" value="<?php echo e($application->user->name); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputCountry">Country</label>
                                            <input type="text" class="form-control" id="inputCountry" value="<?php echo e($application->country->name); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputCountry">Application Type</label>
                                            <input type="text" class="form-control" id="inputCountry" value="<?php echo e($application->application_type); ?>" readonly>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputFirstName">First Name</label>
                                            <input type="text" class="form-control" id="inputFirstName" value="<?php echo e($application->first_name); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputMiddleName">Middle Name</label>
                                            <input type="text" class="form-control" id="inputMiddleName" value="<?php echo e($application->middle_name); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputLastName">Last Name</label>
                                            <input type="text" class="form-control" id="inputLastName" value="<?php echo e($application->last_name); ?>" readonly>
                                        </div>
                                    </div>
                                    <!-- Add more fields as needed -->
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputMotherName">Mother Name</label>
                                            <input type="text" class="form-control" id="inputMotherName" value="<?php echo e($application->mother_name); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputBirthDate">Birth Date</label>
                                            <input type="text" class="form-control" id="inputBirthDate" value="<?php echo e($application->birth_date); ?>" readonly>
                                        </div>

                                        <div class="form-row col-md-4">
                                            <div class="form-group col-md-6">
                                                <label for="inputStatus">Status</label>
                                                <input type="text" class="form-control" id="inputStatus" value="<?php echo e($application->status == 1 ? 'Active' : 'Inactive'); ?>" readonly>
                                            </div>
                                        </div>
                                    </div>
                                    <div class="form-row">
                                        <div class="form-group col-md-4">
                                            <label for="inputMotherName">Marriage Status</label>
                                            <input type="text" class="form-control" id="inputMotherName" value="<?php echo e($application->marriage_status); ?>" readonly>
                                        </div>
                                        <div class="form-group col-md-4">
                                            <label for="inputBirthDate">Education Status</label>
                                            <input type="text" class="form-control" id="inputBirthDate" value="<?php echo e($application->education_status); ?>" readonly>
                                        </div>
                                        <div class="form-row col-md-4">
                                            <div class="form-group col-md-6">
                                                <label for="inputStatus">Asset Overship</label>
                                                <input type="text" class="form-control" id="inputStatus" value="<?php echo e($application->asset_ownership); ?>" readonly>
                                            </div>
                                        </div>

                                    </div>
                                </form>
                                <h2>Extra information</h2>
                                <?php $__currentLoopData = $user_extra_information; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                <?php if($user->id && $user->user_id && $user->status && $user->created_at): ?>
                                <div class="form-row ">
                                 <div class="form-group">
                                     <input type="text" class="form-control" id="inputStatus" value="" readonly>
                                 </div>
                                </div>
                                <?php endif; ?>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                        </div>
                        <!-- /.card-body -->
                    </div>
                    <!-- /.card -->
                    <!-- /.col -->
                </div>
                <!-- /.row -->
            </div>
            <!-- /.container-fluid -->
    </section>
    <!-- /.content -->
</div>
<?php $__env->stopSection(); ?>


<?php echo $__env->make('dashboard.maindashboard', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\yared\Videos\travel\resources\views/users_application/show.blade.php ENDPATH**/ ?>